# Changelog pjdcustom_suche

## 1.3.1 (17.11.2026)

- Mobil: Produkte bei leerem Suchfeld stehen wieder untereinander im 2er-Raster statt in
  einer seitlich wischbaren Reihe.

## 1.3.0 (17.11.2026)

- Leeres Suchfeld kompakter: oben die Schnelllinks als Buttons (z. B. Probefahrt buchen,
  Werkstatt-Termin), darunter genau eine Reihe Produkte (Desktop nebeneinander, mobil wischbar).
  Anzahl einstellbar ("Anzahl Produkte bei leerem Suchfeld", Standard 4).
- Behoben: Am Desktop erschien das Dropdown schon, während das Theme das Suchfeld noch
  aufklappte. Die Karten brachen dabei mehrfach um und sprangen. Das Dropdown wird jetzt
  erst eingeblendet, wenn das Feld fertig aufgeklappt ist.
- Neu: "Bestseller nur aus Bikes (ohne Zubehör)", standardmäßig an. Von Hand ausgewählte
  Produkte werden immer gezeigt.

## 1.2.0 (17.11.2026)

- Neu: Klick ins leere Suchfeld zeigt sofort Produkte (Bestseller bzw. ausgewählte Produkte,
  gleiche Quelle und Anzahl wie bei "Keine Treffer") und die Schnelllinks. Schalter
  "Produkte bei leerem Suchfeld zeigen" in der Karte "Produktempfehlungen".
- Direktlink-Karte neu aufgebaut: Desktop Bild, Text und Button in einer Reihe; mobil Bild
  neben dem Text und der Button sauber über die volle Breite darunter.

## 1.1.0 (17.11.2026)

- Neu: Keine-Treffer-Bereich. Findet Shopware zu einem Begriff nichts, erscheinen unter der
  Ergebnisseite Produkte und Schnelllinks. Einstellbar unter "Keine Treffer": Produktquelle
  (von Hand, Bestseller, kombiniert), Produktauswahl, Anzahl, Texte, Schnelllinks und ob der
  Shopware-Hinweis "Keine Produkte gefunden" ausgeblendet wird.
- Neu: Dieselben Produkte erscheinen auch im Dropdown und im mobilen Overlay, wenn nichts
  gefunden wurde (abschaltbar).
- Neu: Verkaufszahlen im Suchindex (Varianten je Hauptprodukt zusammengezählt) für Bestseller.
  Nach dem Update einmal "Index jetzt neu aufbauen" klicken.
- Behoben: Ein Klick auf einen Treffer klappte das Suchfeld des Themes ein, das Dropdown fuhr
  sichtbar mit. Klicks im Dropdown erreichen das Theme jetzt nicht mehr, das Dropdown bleibt
  bis zum Seitenwechsel stehen.
- Tracking: view mit target no_results_page, select mit target empfehlung.

## 1.0.3 (17.11.2026)

- Behoben: Mobil blieb nach dem Tippen oder Scrollen ein grauer Hover-Rahmen an einzelnen
  Bike-Karten hängen. Hover-Effekte gibt es jetzt nur noch bei Bedienung mit Maus.
- Behoben: Am Desktop erschien das Dropdown manchmal rechts, weil das Theme das Suchfeld
  beim Klick animiert aufklappt. Das Dropdown folgt dem Feld jetzt während und nach der
  Animation und ist immer genau so breit wie das aufgeklappte Suchfeld.
- Breites Dropdown: Bikes in so vielen Spalten wie Platz ist, Kategorien zweispaltig.

## 1.0.2 (16.11.2026)

- Behoben: Der Index wurde nur in der Standardsprache des Verkaufskanals gebaut. Nutzt die
  Domain eine andere Sprache, fand die Suche nichts. Jetzt wird jede Sprache des Kanals
  (Standardsprache und alle Domain-Sprachen) indexiert.
- Neu: Im Debug-Modus enthält die Antwort von /pjdcustom-suche/suggest einen Block "debug"
  mit Kanal, Sprache, geladenen Einträgen und letztem Indexlauf (zur Fehlersuche).
- Antworten der Suche werden nicht mehr im Browser zwischengespeichert.

## 1.0.1 (16.11.2026)

- Behoben: Kategorien wurden nicht in den Index aufgenommen, wenn die Navigations-Wurzel
  des Verkaufskanals selbst unter einer weiteren Kategorie liegt (z. B. gemeinsamer Katalog
  für trenga.de und fahrradcenter.de). Unterzeilen zeigen jetzt nur noch Ebenen unterhalb
  der Navigation.
- Neu: Wurde ein Verkaufskanal noch nie indexiert, startet die erste Suche den Aufbau
  automatisch im Hintergrund.
- Neu: Nach "Index jetzt neu aufbauen" zeigt die Meldung die Anzahl der Kategorien, Bikes
  und Zubehör-Artikel je Verkaufskanal bzw. einen Hinweis, wenn kein Kanal aktiv ist.
- Standardwerte an das TRENGA-Theme angepasst: mobiler Such-Button `.header-search-btn`,
  mobile Ansicht unter 1024 px.

## 1.0.0 (16.11.2026)

Erste Version.

- Eigener Suchindex für Kategorien, Bikes und Zubehör (mit Bild, ab-Preis, Sale-Badge)
- Versteht Groß-/Kleinschreibung, Umlaute, Plural, Modellnummern ("GLG9" = "GLG 9.0"),
  zusammengesetzte Wörter ("Räder" findet "Firmenräder") und kleine Tippfehler
- Synonyme, Direktlinks (z. B. Werkstatt -> Servicetermin) und eigene Einträge
  (Standorte, Service, Schnelllinks), gepflegt unter Marketing > Suche
- Desktop: Dropdown unter dem Suchfeld. Mobil: Vollbild-Overlay mit großen Tippflächen
- Enter: Direktlink, passende Kategorie oder einziger Treffer, sonst Shopware-Ergebnisseite
- Tracking nach pjdcustom-Schema (element = suche), inkl. Suchen ohne Treffer
- Index aktualisiert sich automatisch nach Änderungen (gebündelt, im Hintergrund),
  jede Nacht, per Button im Admin oder per `php bin/console pjdcustom:suche:index`
- Sicherheitsnetz: Bei Server-Fehlern übernimmt sofort wieder die normale Shopware-Suche
- Zusatzfelder "Suche (pjdcustom)" an Kategorien und Produkten
