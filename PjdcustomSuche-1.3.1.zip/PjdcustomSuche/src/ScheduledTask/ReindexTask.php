<?php declare(strict_types=1);

namespace Pjdcustom\Suche\ScheduledTask;

use Shopware\Core\Framework\MessageQueue\ScheduledTask\ScheduledTask;

/**
 * Nächtlicher Komplett-Neuaufbau des Suchindex (Sicherheitsnetz).
 */
class ReindexTask extends ScheduledTask
{
    public static function getTaskName(): string
    {
        return 'pjdcustom_suche.reindex';
    }

    public static function getDefaultInterval(): int
    {
        return 86400;
    }
}
