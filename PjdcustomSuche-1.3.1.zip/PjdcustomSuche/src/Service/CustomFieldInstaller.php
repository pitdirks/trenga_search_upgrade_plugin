<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Service;

use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\CustomField\CustomFieldTypes;

/**
 * Legt die Zusatzfelder "Suche (pjdcustom)" an Kategorien und Produkten an.
 * Wird bei Installation, Aktivierung und jedem Update ausgeführt und ist
 * gefahrlos wiederholbar (bestehende Felder bleiben erhalten).
 */
class CustomFieldInstaller
{
    public const SET_NAME = 'pjdcustom_suche';
    public const FIELD_KEYWORDS = 'pjdcustom_suche_keywords';
    public const FIELD_TEASER = 'pjdcustom_suche_teaser';
    public const FIELD_EXCLUDE = 'pjdcustom_suche_exclude';

    public function __construct(private readonly EntityRepository $setRepository)
    {
    }

    public function install(Context $context): void
    {
        $existingId = $this->findSetId($context);
        $existingFieldNames = [];

        if ($existingId !== null) {
            $criteria = new Criteria([$existingId]);
            $criteria->addAssociation('customFields');
            $set = $this->setRepository->search($criteria, $context)->first();
            if ($set !== null && $set->getCustomFields() !== null) {
                foreach ($set->getCustomFields() as $field) {
                    $existingFieldNames[] = $field->getName();
                }
            }
        }

        $fields = [];
        foreach ($this->fieldDefinitions() as $definition) {
            if (!\in_array($definition['name'], $existingFieldNames, true)) {
                $fields[] = $definition;
            }
        }

        if ($existingId !== null && $fields === []) {
            return;
        }

        $setId = $existingId ?? Uuid::randomHex();
        $payload = [
            'id' => $setId,
            'customFields' => $fields,
        ];

        if ($existingId === null) {
            $payload['name'] = self::SET_NAME;
            $payload['config'] = [
                'label' => [
                    'de-DE' => 'Suche (pjdcustom)',
                    'en-GB' => 'Search (pjdcustom)',
                ],
                'translated' => true,
            ];
            $payload['relations'] = [
                ['entityName' => 'category'],
                ['entityName' => 'product'],
            ];
        }

        $this->setRepository->upsert([$payload], $context);
    }

    public function uninstall(Context $context): void
    {
        $id = $this->findSetId($context);
        if ($id !== null) {
            $this->setRepository->delete([['id' => $id]], $context);
        }
    }

    private function findSetId(Context $context): ?string
    {
        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('name', self::SET_NAME));

        return $this->setRepository->searchIds($criteria, $context)->firstId();
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function fieldDefinitions(): array
    {
        return [
            [
                'name' => self::FIELD_KEYWORDS,
                'type' => CustomFieldTypes::TEXT,
                'config' => [
                    'label' => ['de-DE' => 'Zusätzliche Suchbegriffe', 'en-GB' => 'Additional search terms'],
                    'helpText' => [
                        'de-DE' => 'Kommagetrennt, z. B. "Gravel, Schotter, Adventure". Darüber wird diese Seite bzw. dieses Produkt zusätzlich gefunden.',
                        'en-GB' => 'Comma separated, e.g. "gravel, adventure".',
                    ],
                    'componentName' => 'sw-field',
                    'customFieldType' => 'text',
                    'type' => 'text',
                    'customFieldPosition' => 1,
                ],
            ],
            [
                'name' => self::FIELD_TEASER,
                'type' => CustomFieldTypes::TEXT,
                'config' => [
                    'label' => ['de-DE' => 'Kurztext in der Suche', 'en-GB' => 'Short text in search'],
                    'helpText' => [
                        'de-DE' => 'Optional. Erscheint unter dem Namen im Suchvorschlag. Leer = bei Kategorien der Pfad (z. B. "E-Bikes › Trekking").',
                        'en-GB' => 'Optional. Shown below the name in the search suggestion.',
                    ],
                    'componentName' => 'sw-field',
                    'customFieldType' => 'text',
                    'type' => 'text',
                    'customFieldPosition' => 2,
                ],
            ],
            [
                'name' => self::FIELD_EXCLUDE,
                'type' => CustomFieldTypes::BOOL,
                'config' => [
                    'label' => ['de-DE' => 'Nicht in der Suche anzeigen', 'en-GB' => 'Hide in search'],
                    'componentName' => 'sw-field',
                    'customFieldType' => 'switch',
                    'type' => 'switch',
                    'customFieldPosition' => 3,
                ],
            ],
        ];
    }
}
