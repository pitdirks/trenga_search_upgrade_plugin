<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Service;

use Shopware\Core\System\SystemConfig\SystemConfigService;

/**
 * Liest die Plugin-Einstellungen (config.xml) je Verkaufskanal,
 * immer mit sauberen Standardwerten, falls ein Feld leer ist.
 */
class ConfigReader
{
    public const DOMAIN = 'PjdcustomSuche.config.';

    private const DEFAULTS = [
        'active' => false,
        'inputSelector' => '.header-search-input',
        'mobileTriggerSelector' => '.header-search-btn',
        'mobileBreakpoint' => 1024,
        'minChars' => 2,
        'redirectOnCategoryMatch' => true,
        'showAllResultsLink' => true,
        'trackingEnabled' => true,
        'debug' => false,
        'includeFooterCategories' => false,
        'includeServiceCategories' => false,
        'includeHiddenCategories' => false,
        'excludedCategories' => [],
        'accessoryCategories' => [],
        'showOutOfStock' => true,
        'groupOrder' => 'categories,bikes,accessories,entries',
        'maxHighlights' => 1,
        'maxCategories' => 4,
        'maxBikes' => 6,
        'maxAccessories' => 4,
        'maxEntries' => 3,
        'showImages' => true,
        'showPriceDesktop' => true,
        'showPriceMobile' => true,
        'showSaleBadge' => true,
        'showQuickLinks' => true,
        'noResultsEnabled' => true,
        'noResultsSource' => 'combined',
        'noResultsProducts' => [],
        'bestsellerBikesOnly' => true,
        'noResultsLimit' => 6,
        'emptyShowProducts' => true,
        'emptyProductsLimit' => 4,
        'noResultsInDropdown' => true,
        'noResultsShowQuickLinks' => true,
        'noResultsHideShopwareNotice' => false,
        'textPlaceholder' => '',
        'textMobileTitle' => 'Suche',
        'textClose' => 'Schließen',
        'textClear' => 'Eingabe löschen',
        'textGroupCategories' => 'Kategorien',
        'textGroupBikes' => 'Bikes',
        'textGroupAccessories' => 'Zubehör',
        'textGroupEntries' => 'Standorte & Service',
        'textQuickLinks' => 'Beliebt',
        'textPriceFrom' => 'ab',
        'textSale' => 'Sale',
        'textHighlightButton' => 'Jetzt ansehen',
        'textNoResultsTitle' => 'Dazu haben wir leider nichts gefunden.',
        'textNoResultsText' => 'Probier einen anderen Begriff oder schau hier vorbei:',
        'textAllResults' => 'Alle Ergebnisse für „%term%“',
        'textResultsCount' => '%count% Vorschläge',
        'textRecommendations' => 'Beliebt bei unseren Kunden',
        'textNoResultsPageTitle' => 'Nicht gefunden, was Du suchst?',
        'textNoResultsPageText' => 'Vielleicht ist eins dieser Bikes genau das Richtige für Dich.',
        'textNoResultsPageQuickLinks' => 'Oder schau hier vorbei',
    ];

    /** @var array<string, array<string, mixed>> */
    private array $cache = [];

    private ?string $version = null;

    public function __construct(private readonly SystemConfigService $systemConfig)
    {
    }

    /**
     * @return array<string, mixed>
     */
    public function all(?string $salesChannelId): array
    {
        $key = $salesChannelId ?? 'default';
        if (isset($this->cache[$key])) {
            return $this->cache[$key];
        }

        $config = [];
        foreach (self::DEFAULTS as $name => $default) {
            $value = $this->systemConfig->get(self::DOMAIN . $name, $salesChannelId);

            if (\is_bool($default)) {
                $config[$name] = $value === null ? $default : (bool) $value;
            } elseif (\is_int($default)) {
                $config[$name] = ($value === null || $value === '') ? $default : max(0, (int) $value);
            } elseif (\is_array($default)) {
                $config[$name] = \is_array($value) ? array_values(array_filter($value, 'is_string')) : [];
            } else {
                $config[$name] = \is_string($value) ? trim($value) : $default;
                // Pflichttexte nie leer ausgeben (Platzhalter darf leer sein)
                if ($config[$name] === '' && !\in_array($name, ['textPlaceholder', 'mobileTriggerSelector', 'textNoResultsPageText'], true)) {
                    $config[$name] = $default;
                }
            }
        }

        return $this->cache[$key] = $config;
    }

    public function isActive(?string $salesChannelId): bool
    {
        return (bool) $this->all($salesChannelId)['active'];
    }

    /**
     * Plugin-Version aus der composer.json (für Tracking und Debug).
     */
    public function pluginVersion(): string
    {
        if ($this->version !== null) {
            return $this->version;
        }

        $file = \dirname(__DIR__, 2) . '/composer.json';
        $data = is_file($file) ? json_decode((string) file_get_contents($file), true) : null;

        return $this->version = \is_array($data) && isset($data['version']) ? (string) $data['version'] : '0.0.0';
    }

    public function reset(): void
    {
        $this->cache = [];
    }
}
