<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Service;

/**
 * Bringt Suchbegriffe und Inhalte in eine vergleichbare Form.
 *
 *   "E-Bikes"      -> e, bik, ebik
 *   "GLG 9.0"      -> glg, 9, glg9
 *   "Gravel Bikes" -> gravel, bik, gravelbik
 *   "Räder"        -> raed
 *
 * Regeln:
 *   - Klein, Umlaute als ae/oe/ue/ss, Akzente entfernt
 *   - "9.0" wird "9", "9.2" wird "92" (Modellnummern)
 *   - leichte Wortstamm-Kürzung (Plural/Endungen), identisch für Index und Suche
 *   - zusätzlich zusammengezogene Wortpaare, damit "Gravel Bike" = "Gravelbike"
 */
class TextNormalizer
{
    private const CHAR_MAP = [
        'ä' => 'ae', 'ö' => 'oe', 'ü' => 'ue', 'ß' => 'ss',
        'á' => 'a', 'à' => 'a', 'â' => 'a', 'å' => 'a', 'ã' => 'a',
        'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
        'í' => 'i', 'ì' => 'i', 'î' => 'i', 'ï' => 'i',
        'ó' => 'o', 'ò' => 'o', 'ô' => 'o', 'õ' => 'o', 'ø' => 'o',
        'ú' => 'u', 'ù' => 'u', 'û' => 'u',
        'ç' => 'c', 'ñ' => 'n', 'ÿ' => 'y', 'ý' => 'y',
    ];

    private const STOPWORDS = [
        'der', 'die', 'das', 'den', 'dem', 'des', 'ein', 'eine', 'einen', 'einem', 'einer',
        'und', 'oder', 'mit', 'fuer', 'von', 'vom', 'zum', 'zur', 'im', 'in', 'am', 'an', 'auf', 'bei',
        'the', 'and', 'for', 'of',
    ];

    private const SUFFIXES = ['ern', 'en', 'er', 'es', 'e', 's', 'n'];

    /** @var array<string, list<string>> */
    private array $tokenCache = [];

    public function normalize(string $text): string
    {
        $text = mb_strtolower(strip_tags($text), 'UTF-8');
        $text = strtr($text, self::CHAR_MAP);
        // Modellnummern: 9.0 -> 9, 9,0 -> 9, 9.2 -> 92
        $text = (string) preg_replace('/(\d+)[.,]0+(?!\d)/', '$1', $text);
        $text = (string) preg_replace('/(\d+)[.,](\d+)/', '$1$2', $text);
        $text = (string) preg_replace('/[^a-z0-9]+/', ' ', $text);

        return trim((string) preg_replace('/\s+/', ' ', $text));
    }

    public function stem(string $token): string
    {
        if (\strlen($token) < 4 || preg_match('/\d/', $token)) {
            return $token;
        }

        foreach (self::SUFFIXES as $suffix) {
            $len = \strlen($suffix);
            if (substr($token, -$len) === $suffix && \strlen($token) - $len >= 3) {
                return substr($token, 0, -$len);
            }
        }

        return $token;
    }

    /**
     * Wörter einer Eingabe (normalisiert + gekürzt), ohne Füllwörter.
     *
     * @return list<string>
     */
    public function words(string $text, bool $dropStopwords = true): array
    {
        $normalized = $this->normalize($text);
        if ($normalized === '') {
            return [];
        }

        $words = [];
        foreach (explode(' ', $normalized) as $word) {
            if ($word === '') {
                continue;
            }
            if ($dropStopwords && \in_array($word, self::STOPWORDS, true)) {
                continue;
            }
            $words[] = $this->stem($word);
        }

        // Besteht die Eingabe nur aus Füllwörtern, diese doch verwenden
        if ($words === [] && $dropStopwords) {
            return $this->words($text, false);
        }

        return $words;
    }

    /**
     * Alle Such-Token eines Textes: Wörter plus zusammengezogene Nachbarpaare.
     *
     * @return list<string>
     */
    public function tokens(string $text): array
    {
        if (isset($this->tokenCache[$text])) {
            return $this->tokenCache[$text];
        }

        $words = $this->words($text);
        $tokens = $words;
        $count = \count($words);
        for ($i = 0; $i < $count - 1; ++$i) {
            $tokens[] = $words[$i] . $words[$i + 1];
        }
        // auch das ganze Wort ohne Trennung, z. B. "e-bike" -> "ebik"
        if ($count > 2 && $count <= 4) {
            $tokens[] = implode('', $words);
        }

        $tokens = array_values(array_unique(array_filter($tokens, static fn (string $t) => $t !== '')));

        if (\count($this->tokenCache) > 5000) {
            $this->tokenCache = [];
        }

        return $this->tokenCache[$text] = $tokens;
    }

    /**
     * Ein Begriff als ein einziges Vergleichs-Token, z. B. "E-Bike" -> "ebik".
     */
    public function joined(string $text): string
    {
        return implode('', $this->words($text, false));
    }

    /**
     * Kommagetrennte bzw. zeilenweise Liste in einzelne Begriffe zerlegen.
     *
     * @return list<string>
     */
    public function splitList(?string $text): array
    {
        if ($text === null || trim($text) === '') {
            return [];
        }

        $parts = preg_split('/[,;\n\r|]+/', $text) ?: [];

        return array_values(array_filter(array_map('trim', $parts), static fn (string $p) => $p !== ''));
    }
}
