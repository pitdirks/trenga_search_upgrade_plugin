<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Service;

use Doctrine\DBAL\ArrayParameterType;
use Doctrine\DBAL\Connection;
use Pjdcustom\Suche\Entity\Entry\EntryEntity;
use Pjdcustom\Suche\Entity\Rule\RuleEntity;
use Pjdcustom\Suche\Entity\Synonym\SynonymEntity;
use Shopware\Core\Defaults;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Sorting\FieldSorting;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Symfony\Contracts\Cache\ItemInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;

/**
 * Verbindet die Suchlogik mit Shopware: lädt Index, Einträge, Direktlinks und
 * Synonyme (einmal aufbereitet im Cache) und formt das Ergebnis für die Storefront.
 *
 * Der Cache wird automatisch geleert, sobald der Index neu gebaut oder im Admin
 * etwas an Direktlinks, Synonymen oder Einträgen gespeichert wird.
 */
class SearchService
{
    private const CACHE_LIFETIME = 86400;
    private const MAX_QUERY_LENGTH = 80;

    /** @var array<string, array<string, mixed>> */
    private array $memory = [];

    public function __construct(
        private readonly Connection $connection,
        private readonly SearchEngine $engine,
        private readonly ConfigReader $config,
        private readonly TagAwareCacheInterface $cache,
        private readonly EntityRepository $ruleRepository,
        private readonly EntityRepository $synonymRepository,
        private readonly EntityRepository $entryRepository,
        private readonly ReindexScheduler $scheduler
    ) {
    }

    /**
     * @return array<string, mixed>
     */
    public function suggest(string $query, SalesChannelContext $context, string $baseUrl): array
    {
        $salesChannelId = $context->getSalesChannelId();
        $config = $this->config->all($salesChannelId);
        $query = mb_substr(trim($query), 0, self::MAX_QUERY_LENGTH);
        $data = $this->data($salesChannelId, $context->getLanguageId(), $context->getContext());

        $quickLinks = $config['showQuickLinks']
            ? array_map(fn (array $doc) => $this->formatDoc($doc, $baseUrl, 'schnelllink'), $data['quick'])
            : [];

        if (mb_strlen($query) < max(1, (int) $config['minChars'])) {
            // Leeres Suchfeld: Schnelllinks und (falls aktiv) Bestseller bzw. ausgewählte Produkte
            return [
                'q' => $query,
                'total' => 0,
                'groups' => [],
                'highlights' => [],
                'redirect' => null,
                'redirectType' => null,
                'quick' => $quickLinks,
                'recommendations' => $config['emptyShowProducts'] ? $this->recommendations($context, $baseUrl, (int) $config['emptyProductsLimit']) : [],
            ];
        }

        $result = $this->engine->search($data, $query, [
            'category' => (int) $config['maxCategories'],
            'bike' => (int) $config['maxBikes'],
            'accessory' => (int) $config['maxAccessories'],
            'entry' => (int) $config['maxEntries'],
            'highlight' => (int) $config['maxHighlights'],
        ]);

        $groupKeys = ['categories' => 'category', 'bikes' => 'bike', 'accessories' => 'accessory', 'entries' => 'entry'];
        $order = array_values(array_unique(array_filter(
            array_map('trim', explode(',', strtolower((string) $config['groupOrder']))),
            static fn (string $key) => isset($groupKeys[$key])
        )));
        foreach (array_keys($groupKeys) as $key) {
            if (!\in_array($key, $order, true)) {
                $order[] = $key;
            }
        }

        $groups = [];
        foreach ($order as $key) {
            $type = $groupKeys[$key];
            $items = $result['hits'][$type] ?? [];
            if ($items === []) {
                continue;
            }
            $groups[] = [
                'key' => $key,
                'count' => $result['counts'][$type] ?? \count($items),
                'items' => array_map(fn (array $doc) => $this->formatDoc($doc, $baseUrl), $items),
            ];
        }

        $highlights = array_map(fn (array $rule) => [
            'title' => $rule['title'],
            'text' => $rule['text'],
            'button' => $rule['button'],
            'url' => $this->absolute($rule['url'], $baseUrl, false),
            'img' => $config['showImages'] ? $rule['img'] : null,
            'track' => ['target' => 'direktlink'],
        ], $result['highlights']);

        $redirect = null;
        $redirectType = null;
        if ($result['redirect'] !== null) {
            $redirect = $this->absolute($result['redirect'], $baseUrl, false);
            $redirectType = 'direktlink';
        } elseif ($config['redirectOnCategoryMatch'] && ($result['categoryRedirect'] ?? null) !== null) {
            $redirect = $this->absolute($result['categoryRedirect'], $baseUrl, true);
            $redirectType = 'kategorie';
        }

        $total = (int) $result['total'] + \count($highlights);

        $recommendations = $total === 0 && $config['noResultsInDropdown']
            ? $this->recommendations($context, $baseUrl)
            : [];

        $payload = [
            'q' => $query,
            'total' => $total,
            'groups' => $groups,
            'highlights' => $highlights,
            'redirect' => $redirect,
            'redirectType' => $redirectType,
            'quick' => $total === 0 ? $quickLinks : [],
            'recommendations' => $recommendations,
        ];

        if ($config['debug']) {
            $payload['debug'] = $this->diagnostics($data, $salesChannelId, $context->getLanguageId());
        }

        return $payload;
    }

    /**
     * Nur im Debug-Modus: Zustand des Index für diese Anfrage (keine Kundendaten).
     *
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    private function diagnostics(array $data, string $salesChannelId, string $languageId): array
    {
        $types = [];
        foreach ($data['docs'] as $doc) {
            $types[$doc['type']] = ($types[$doc['type']] ?? 0) + 1;
        }

        $rowsPerLanguage = $this->connection->fetchAllKeyValue(
            'SELECT LOWER(HEX(`language_id`)), COUNT(*) FROM `pjdcustom_suche_index` WHERE `sales_channel_id` = :sc GROUP BY `language_id`',
            ['sc' => Uuid::fromHexToBytes($salesChannelId)]
        );
        $state = $this->connection->fetchOne(
            'SELECT `value` FROM `pjdcustom_suche_state` WHERE `state_key` = :key',
            ['key' => 'index:' . $salesChannelId]
        );

        return [
            'salesChannelId' => $salesChannelId,
            'languageId' => $languageId,
            'loadedDocuments' => $types,
            'directLinks' => \count($data['rules']),
            'synonymTerms' => \count($data['syn']),
            'indexRowsPerLanguage' => $rowsPerLanguage,
            'lastIndexRun' => \is_string($state) ? json_decode($state, true) : null,
            'pluginVersion' => $this->config->pluginVersion(),
        ];
    }

    /**
     * Produkte für den Keine-Treffer-Bereich (Ergebnisseite und Dropdown),
     * fertig formatiert wie die Suchvorschläge.
     *
     * @return list<array<string, mixed>>
     */
    public function recommendations(SalesChannelContext $context, string $baseUrl, ?int $limit = null): array
    {
        $config = $this->config->all($context->getSalesChannelId());
        $data = $this->data($context->getSalesChannelId(), $context->getLanguageId(), $context->getContext());
        $limit = max(1, min(12, $limit ?? (int) $config['noResultsLimit']));
        $source = \in_array($config['noResultsSource'], ['manual', 'bestseller', 'combined'], true)
            ? $config['noResultsSource']
            : 'combined';

        $docs = $this->engine->recommend($data, $this->mainProductIds($config['noResultsProducts']), $source, $limit, (bool) $config['bestsellerBikesOnly']);

        return array_map(fn (array $doc) => $this->formatDoc($doc, $baseUrl, 'empfehlung'), $docs);
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function quickLinks(SalesChannelContext $context, string $baseUrl): array
    {
        $data = $this->data($context->getSalesChannelId(), $context->getLanguageId(), $context->getContext());

        return array_map(fn (array $doc) => $this->formatDoc($doc, $baseUrl, 'schnelllink'), $data['quick']);
    }

    /**
     * Ausgewählte Varianten auf ihr Hauptprodukt abbilden (im Index stehen nur Hauptprodukte).
     *
     * @param list<string> $ids
     *
     * @return list<string>
     */
    private function mainProductIds(array $ids): array
    {
        $ids = array_values(array_filter($ids, static fn ($id) => \is_string($id) && Uuid::isValid($id)));
        if ($ids === []) {
            return [];
        }

        $parents = $this->connection->fetchAllKeyValue(
            'SELECT LOWER(HEX(`id`)), LOWER(HEX(`parent_id`)) FROM `product`
             WHERE `id` IN (:ids) AND `version_id` = :version AND `parent_id` IS NOT NULL',
            ['ids' => Uuid::fromHexToBytesList($ids), 'version' => Uuid::fromHexToBytes(Defaults::LIVE_VERSION)],
            ['ids' => ArrayParameterType::BINARY]
        );

        return array_values(array_unique(array_map(
            static fn (string $id) => (string) ($parents[strtolower($id)] ?? strtolower($id)),
            $ids
        )));
    }

    /**
     * @return array<string, mixed>
     */
    public function data(string $salesChannelId, string $languageId, Context $context): array
    {
        $key = 'pjdcustom_suche_data_' . $salesChannelId . '_' . $languageId;

        if (isset($this->memory[$key])) {
            return $this->memory[$key];
        }

        $data = $this->cache->get($key, function (ItemInterface $item) use ($salesChannelId, $languageId, $context): array {
            $item->tag([SearchIndexer::CACHE_TAG]);
            $item->expiresAfter(self::CACHE_LIFETIME);

            return $this->buildData($salesChannelId, $languageId, $context);
        });

        if (\count($this->memory) > 4) {
            $this->memory = [];
        }

        return $this->memory[$key] = $data;
    }

    public function reset(): void
    {
        $this->memory = [];
    }

    /**
     * @return array<string, mixed>
     */
    private function buildData(string $salesChannelId, string $languageId, Context $context): array
    {
        $rows = $this->connection->fetchAllAssociative(
            'SELECT `type`, LOWER(HEX(`entity_id`)) AS `entity_id`, `sales`, `title`, `subtitle`, `url`, `image`, `price_formatted`, `is_sale`, `bike_model`,
                    `bike_variant`, `keywords_text`, `context_text`, `position`
             FROM `pjdcustom_suche_index`
             WHERE `sales_channel_id` = :sc AND `language_id` = :lang
             ORDER BY `type`, `position`',
            ['sc' => Uuid::fromHexToBytes($salesChannelId), 'lang' => Uuid::fromHexToBytes($languageId)]
        );

        // Noch nie indexiert (z. B. direkt nach der Installation)? Dann im Hintergrund nachholen.
        if ($rows === []) {
            $state = $this->connection->fetchOne(
                'SELECT 1 FROM `pjdcustom_suche_state` WHERE `state_key` = :key',
                ['key' => 'index:' . $salesChannelId]
            );
            if ($state === false) {
                $this->scheduler->schedule();
            }
        }

        $config = $this->config->all($salesChannelId);
        $showImages = (bool) $config['showImages'];
        if (!$showImages) {
            foreach ($rows as &$row) {
                $row['image'] = null;
            }
            unset($row);
        }

        $entries = [];
        foreach ($this->loadActive($this->entryRepository, $context, true) as $entry) {
            /** @var EntryEntity $entry */
            $entries[] = [
                'type' => $entry->getType(),
                'title' => $entry->getTitle(),
                'description' => $entry->getDescription(),
                'url' => $entry->getUrl(),
                'keywords' => $entry->getKeywords(),
                'quickLink' => $entry->getQuickLink(),
                'image' => $showImages ? MediaUrl::forMedia($entry->getMedia()) : null,
            ];
        }

        $rules = [];
        foreach ($this->loadActive($this->ruleRepository, $context, true) as $rule) {
            /** @var RuleEntity $rule */
            $rules[] = [
                'title' => $rule->getTitle(),
                'description' => $rule->getDescription(),
                'buttonLabel' => $rule->getButtonLabel() ?: $config['textHighlightButton'],
                'url' => $rule->getUrl(),
                'keywords' => $rule->getKeywords(),
                'redirectOnEnter' => $rule->getRedirectOnEnter(),
                'image' => MediaUrl::forMedia($rule->getMedia()),
            ];
        }

        $synonyms = [];
        foreach ($this->loadActive($this->synonymRepository, $context, false) as $synonym) {
            /** @var SynonymEntity $synonym */
            $synonyms[] = $synonym->getTerms();
        }

        return $this->engine->buildData($rows, $entries, $rules, $synonyms);
    }

    /**
     * @return iterable<mixed>
     */
    private function loadActive(EntityRepository $repository, Context $context, bool $withMedia): iterable
    {
        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('active', true));
        if ($withMedia) {
            $criteria->addAssociation('media');
            $criteria->addSorting(new FieldSorting('position'));
        }
        $criteria->addSorting(new FieldSorting('createdAt'));
        $criteria->setLimit(500);

        return $repository->search($criteria, $context)->getEntities();
    }

    /**
     * @param array<string, mixed> $doc
     *
     * @return array<string, mixed>
     */
    private function formatDoc(array $doc, string $baseUrl, ?string $forcedTarget = null): array
    {
        $target = $forcedTarget ?? match ($doc['type']) {
            'category' => 'kategorie',
            'bike' => 'bike',
            'accessory' => 'zubehoer',
            default => $doc['etype'] ?? 'eintrag',
        };

        return [
            'type' => $doc['type'],
            'title' => $doc['title'],
            'sub' => $doc['sub'],
            'url' => $this->absolute($doc['url'], $baseUrl, (bool) $doc['rel']),
            'img' => $doc['img'],
            'price' => $doc['price'],
            'sale' => $doc['sale'],
            'track' => [
                'target' => $target,
                'bike_model' => $doc['bm'],
                'bike_variant' => $doc['bv'],
            ],
        ];
    }

    private function absolute(string $url, string $baseUrl, bool $relativeToShop): string
    {
        if ($relativeToShop && str_starts_with($url, '/')) {
            return rtrim($baseUrl, '/') . $url;
        }

        return $url;
    }
}
