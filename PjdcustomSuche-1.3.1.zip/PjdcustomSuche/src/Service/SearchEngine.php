<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Service;

/**
 * Die eigentliche Suchlogik, unabhängig von Shopware (dadurch testbar).
 *
 * 1. buildData(): bereitet Index, eigene Einträge, Direktlinks und Synonyme
 *    einmalig auf (wird gecacht). Kern ist ein invertierter Index:
 *    Token -> [Dokument => Gewicht].
 * 2. search(): zerlegt die Eingabe, erweitert sie um Synonyme, sucht jedes
 *    Wort exakt, als Wortanfang und fehlertolerant im Wortschatz und
 *    bewertet die Treffer.
 *
 * Gewichtung: Titel 3, Suchbegriffe 2,5, Kontext (Kategorien, Eigenschaften) 1,
 * Beschreibung 0,6. Exakt 1,0 / Wortanfang ca. 0,8 / Tippfehler 0,4–0,65.
 */
class SearchEngine
{
    private const W_TITLE = 3.0;
    private const W_KEYWORDS = 2.5;
    private const W_CONTEXT = 1.0;
    private const W_DESCRIPTION = 0.6;
    private const SYNONYM_FACTOR = 0.9;
    private const MAX_WORDS = 6;

    /** @var array<string, array<string, float>> */
    private array $vocabMatchCache = [];

    public function __construct(private readonly TextNormalizer $normalizer)
    {
    }

    /**
     * @param list<array<string, mixed>> $indexRows
     * @param list<array<string, mixed>> $entries
     * @param list<array<string, mixed>> $rules
     * @param list<string>               $synonymLists
     *
     * @return array<string, mixed>
     */
    public function buildData(array $indexRows, array $entries, array $rules, array $synonymLists): array
    {
        $docs = [];
        $inv = [];
        $quick = [];

        foreach ($indexRows as $row) {
            $idx = \count($docs);
            $title = (string) $row['title'];
            $docs[] = [
                'type' => (string) $row['type'],
                'id' => isset($row['entity_id']) ? (string) $row['entity_id'] : null,
                'sales' => (int) ($row['sales'] ?? 0),
                'title' => $title,
                'sub' => $row['subtitle'] !== null && $row['subtitle'] !== '' ? (string) $row['subtitle'] : null,
                'url' => (string) $row['url'],
                'rel' => true,
                'img' => $row['image'] ?: null,
                'price' => $row['price_formatted'] ?: null,
                'sale' => (bool) $row['is_sale'],
                'bm' => $row['bike_model'] ?: null,
                'bv' => $row['bike_variant'] ?: null,
                'pos' => (int) $row['position'],
                'tj' => $this->normalizer->joined($title),
                'tw' => $this->normalizer->words($title, false),
                'kj' => $this->joinedList((string) ($row['keywords_text'] ?? '')),
            ];
            $this->addTokens($inv, $idx, $title, self::W_TITLE);
            $this->addListTokens($inv, $idx, (string) ($row['keywords_text'] ?? ''), self::W_KEYWORDS);
            $this->addTokens($inv, $idx, (string) ($row['context_text'] ?? ''), self::W_CONTEXT);
        }

        $entryPosition = 0;
        foreach ($entries as $entry) {
            $url = MediaUrl::safeLink($entry['url'] ?? null);
            $title = trim((string) ($entry['title'] ?? ''));
            if ($url === null || $title === '') {
                continue;
            }
            $payload = [
                'type' => 'entry',
                'etype' => \in_array($entry['type'] ?? '', ['standort', 'service'], true) ? $entry['type'] : 'eintrag',
                'title' => $title,
                'sub' => trim((string) ($entry['description'] ?? '')) ?: null,
                'url' => $url,
                'rel' => false,
                'img' => $entry['image'] ?? null,
                'price' => null,
                'sale' => false,
                'bm' => null,
                'bv' => null,
                'pos' => $entryPosition++,
                'tj' => $this->normalizer->joined($title),
                'tw' => $this->normalizer->words($title, false),
                'kj' => $this->joinedList((string) ($entry['keywords'] ?? '')),
            ];
            if (!empty($entry['quickLink'])) {
                $quick[] = $payload;
            }
            $idx = \count($docs);
            $docs[] = $payload;
            $this->addTokens($inv, $idx, $title, self::W_TITLE);
            $this->addListTokens($inv, $idx, (string) ($entry['keywords'] ?? ''), self::W_KEYWORDS);
            $this->addTokens($inv, $idx, (string) ($entry['description'] ?? ''), self::W_DESCRIPTION);
        }

        $preparedRules = [];
        foreach ($rules as $rule) {
            $url = MediaUrl::safeLink($rule['url'] ?? null);
            if ($url === null || trim((string) ($rule['title'] ?? '')) === '') {
                continue;
            }
            $keys = [];
            foreach ($this->normalizer->splitList((string) ($rule['keywords'] ?? '')) as $keyword) {
                $words = $this->normalizer->words($keyword, false);
                if ($words !== []) {
                    $keys[] = ['j' => implode('', $words), 'w' => $words];
                }
            }
            if ($keys === []) {
                continue;
            }
            $preparedRules[] = [
                'title' => trim((string) $rule['title']),
                'text' => trim((string) ($rule['description'] ?? '')) ?: null,
                'button' => trim((string) ($rule['buttonLabel'] ?? '')) ?: null,
                'url' => $url,
                'img' => $rule['image'] ?? null,
                'redirect' => !empty($rule['redirectOnEnter']),
                'keys' => $keys,
            ];
        }

        $synonyms = [];
        foreach ($synonymLists as $list) {
            $terms = array_values(array_unique(array_filter(array_map(
                fn (string $term) => $this->normalizer->joined($term),
                $this->normalizer->splitList($list)
            ))));
            if (\count($terms) < 2) {
                continue;
            }
            foreach ($terms as $term) {
                foreach ($terms as $other) {
                    if ($other !== $term) {
                        $synonyms[$term][$other] = true;
                    }
                }
            }
        }
        $synonyms = array_map('array_keys', $synonyms);

        return [
            'docs' => $docs,
            'inv' => $inv,
            'rules' => $preparedRules,
            'syn' => $synonyms,
            'quick' => $quick,
        ];
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, int>   $limits  z. B. ['category' => 4, 'bike' => 6, 'accessory' => 4, 'entry' => 3, 'highlight' => 1]
     *
     * @return array{
     *     hits: array<string, list<array<string, mixed>>>,
     *     counts: array<string, int>,
     *     highlights: list<array<string, mixed>>,
     *     redirect: ?string,
     *     redirectType: ?string,
     *     categoryRedirect?: ?string,
     *     total: int
     * }
     */
    public function search(array $data, string $query, array $limits): array
    {
        $this->vocabMatchCache = [];
        $empty = ['hits' => [], 'counts' => [], 'highlights' => [], 'redirect' => null, 'redirectType' => null, 'total' => 0];

        $words = \array_slice($this->normalizer->words($query), 0, self::MAX_WORDS);
        if ($words === []) {
            return $empty;
        }

        $groups = $this->buildGroups($words, $data['syn']);
        $scores = $this->scoreDocuments($groups, $data['inv'], \count($data['docs']));

        $queryJoined = implode('', $words);
        $hits = [];
        $counts = [];
        $threshold = 0.45 * \count($groups);

        foreach ($scores as $idx => $score) {
            $doc = $data['docs'][$idx];
            if ($doc['tj'] === $queryJoined || \in_array($queryJoined, $doc['kj'], true)) {
                $score += 4.0;
            } elseif (str_starts_with($doc['tj'], $queryJoined)) {
                $score += 1.5;
            }
            if ($score < $threshold) {
                continue;
            }
            $type = $doc['type'];
            $hits[$type][] = ['score' => $score, 'idx' => $idx];
        }

        foreach ($hits as $type => $list) {
            usort($list, static function (array $a, array $b) use ($data): int {
                return [$b['score'], $data['docs'][$a['idx']]['pos']] <=> [$a['score'], $data['docs'][$b['idx']]['pos']];
            });
            $counts[$type] = \count($list);
            $hits[$type] = $list;
        }

        // Direktlinks
        $highlights = $this->matchRules($data['rules'], $words, $groups, $queryJoined);
        $redirect = null;
        $redirectType = null;
        if ($highlights !== [] && $highlights[0]['redirect'] && $highlights[0]['strength'] >= 2.0) {
            $redirect = $highlights[0]['url'];
            $redirectType = 'direktlink';
        }

        // Enter -> Kategorie, wenn alle Wörter exakt im Kategorienamen oder ein Suchbegriff exakt passt
        $categoryRedirect = null;
        if (isset($hits['category'])) {
            $best = null;
            foreach ($hits['category'] as $hit) {
                $doc = $data['docs'][$hit['idx']];
                $exact = \in_array($queryJoined, $doc['kj'], true) || $doc['tj'] === $queryJoined || array_diff($words, $doc['tw']) === [];
                if (!$exact) {
                    continue;
                }
                $rank = [\count($doc['tw']), $doc['pos']];
                if ($best === null || $rank < $best['rank']) {
                    $best = ['rank' => $rank, 'url' => $doc['url']];
                }
            }
            $categoryRedirect = $best['url'] ?? null;
        }

        $result = $empty;
        $result['counts'] = $counts;
        $result['total'] = array_sum($counts);
        $result['highlights'] = \array_slice($highlights, 0, max(0, $limits['highlight'] ?? 1));
        $result['redirect'] = $redirect;
        $result['redirectType'] = $redirectType;
        $result['categoryRedirect'] = $categoryRedirect;

        foreach ($hits as $type => $list) {
            $limit = $limits[$type] ?? 4;
            $result['hits'][$type] = array_map(
                static fn (array $hit) => $data['docs'][$hit['idx']],
                \array_slice($list, 0, max(0, $limit))
            );
        }

        return $result;
    }

    /**
     * Produkte für den Keine-Treffer-Bereich.
     *
     *   manual     nur die im Backend ausgewählten Produkte (in dieser Reihenfolge)
     *   bestseller meistverkaufte Produkte (Varianten zusammengezählt)
     *   combined   zuerst die Auswahl, dann mit Bestsellern aufgefüllt
     *
     * Gibt es noch keine Verkaufszahlen, wird in der Reihenfolge des Shops aufgefüllt.
     *
     * @param array<string, mixed> $data
     * @param list<string>         $manualIds Hauptprodukt-IDs (hex)
     * @param bool                 $bestsellerBikesOnly Bestseller-Auffüllung nur aus Bikes
     *
     * @return list<array<string, mixed>>
     */
    public function recommend(array $data, array $manualIds, string $source, int $limit, bool $bestsellerBikesOnly = true): array
    {
        if ($limit <= 0) {
            return [];
        }

        $products = [];
        foreach ($data['docs'] as $doc) {
            if (($doc['type'] === 'bike' || $doc['type'] === 'accessory') && !empty($doc['id'])) {
                $products[$doc['id']] = $doc;
            }
        }

        $result = [];
        if ($source === 'manual' || $source === 'combined') {
            foreach ($manualIds as $id) {
                if (isset($products[$id]) && !isset($result[$id])) {
                    $result[$id] = $products[$id];
                }
                if (\count($result) >= $limit) {
                    break;
                }
            }
        }

        if (($source === 'bestseller' || $source === 'combined') && \count($result) < $limit) {
            $ranked = array_values(array_filter(
                $products,
                static fn (array $doc) => !$bestsellerBikesOnly || $doc['type'] === 'bike'
            ));
            usort($ranked, static fn (array $a, array $b) => [$b['sales'], $a['type'] === 'bike' ? 0 : 1, $a['pos']] <=> [$a['sales'], $b['type'] === 'bike' ? 0 : 1, $b['pos']]);
            foreach ($ranked as $doc) {
                if (!isset($result[$doc['id']])) {
                    $result[$doc['id']] = $doc;
                }
                if (\count($result) >= $limit) {
                    break;
                }
            }
        }

        return array_values($result);
    }

    /**
     * Wörter zu Gruppen zusammenfassen. Mehrwort-Synonyme ("tiefer einstieg")
     * werden zu einer Gruppe; jede Gruppe hat Alternativen mit Faktor.
     *
     * @param list<string>                $words
     * @param array<string, list<string>> $synonyms
     *
     * @return list<array<string, float>>
     */
    private function buildGroups(array $words, array $synonyms): array
    {
        $groups = [];
        $count = \count($words);
        $i = 0;

        while ($i < $count) {
            $matched = false;
            for ($span = min(3, $count - $i); $span >= 2; --$span) {
                $joined = implode('', \array_slice($words, $i, $span));
                if (isset($synonyms[$joined])) {
                    $alts = [$joined => 1.0];
                    foreach ($synonyms[$joined] as $alt) {
                        $alts[$alt] ??= self::SYNONYM_FACTOR;
                    }
                    $groups[] = $alts;
                    $i += $span;
                    $matched = true;
                    break;
                }
            }
            if ($matched) {
                continue;
            }

            $word = $words[$i];
            $alts = [$word => 1.0];
            foreach ($synonyms[$word] ?? [] as $alt) {
                $alts[$alt] ??= self::SYNONYM_FACTOR;
            }
            $groups[] = $alts;
            ++$i;
        }

        return $groups;
    }

    /**
     * @param list<array<string, float>>              $groups
     * @param array<string, array<int, float>>        $inv
     *
     * @return array<int, float>
     */
    private function scoreDocuments(array $groups, array $inv, int $docCount): array
    {
        $groupScores = [];
        foreach ($groups as $g => $alts) {
            $groupScores[$g] = [];
            foreach ($alts as $alt => $factor) {
                foreach ($this->matchVocabulary((string) $alt, $inv) as $token => $tokenScore) {
                    foreach ($inv[$token] as $idx => $weight) {
                        $score = $tokenScore * $weight * $factor;
                        if ($score > ($groupScores[$g][$idx] ?? 0.0)) {
                            $groupScores[$g][$idx] = $score;
                        }
                    }
                }
            }
        }

        $groupCount = \count($groups);
        $totals = [];
        $matchedGroups = [];
        foreach ($groupScores as $scores) {
            foreach ($scores as $idx => $score) {
                $totals[$idx] = ($totals[$idx] ?? 0.0) + $score;
                $matchedGroups[$idx] = ($matchedGroups[$idx] ?? 0) + 1;
            }
        }

        // Standard: alle Wörter müssen passen
        $result = [];
        foreach ($totals as $idx => $total) {
            if ($matchedGroups[$idx] === $groupCount) {
                $result[$idx] = $total;
            }
        }

        // Nichts gefunden? Dann reicht es, wenn alle bis auf ein Wort passen.
        if ($result === [] && $groupCount >= 2) {
            foreach ($totals as $idx => $total) {
                if ($matchedGroups[$idx] >= $groupCount - 1) {
                    $result[$idx] = $total * 0.7;
                }
            }
        }

        return $result;
    }

    /**
     * Ein Such-Wort gegen den gesamten Wortschatz prüfen.
     *
     * @param array<string, array<int, float>> $inv
     *
     * @return array<string, float> Token => Trefferqualität
     */
    private function matchVocabulary(string $needle, array $inv): array
    {
        if (isset($this->vocabMatchCache[$needle])) {
            return $this->vocabMatchCache[$needle];
        }

        $matches = [];
        $len = \strlen($needle);
        $hasDigit = (bool) preg_match('/\d/', $needle);
        $allowPrefix = $len >= 2 || $hasDigit;
        $maxDistance = $hasDigit ? 0 : ($len >= 8 ? 2 : ($len >= 5 ? 1 : 0));

        foreach ($inv as $token => $_) {
            $token = (string) $token;
            if ($token === $needle) {
                $matches[$token] = 1.0;
                continue;
            }
            $tokenLen = \strlen($token);
            if ($allowPrefix && $tokenLen > $len && str_starts_with($token, $needle)) {
                $matches[$token] = 0.75 + 0.2 * ($len / $tokenLen);
                continue;
            }
            // Wortteil in zusammengesetzten Wörtern ("raeder" in "firmenraeder", "tasche" in "packtasche")
            if (!$hasDigit && $len >= 4 && $tokenLen > $len && str_contains($token, $needle)) {
                $matches[$token] = 0.55;
                continue;
            }
            if ($maxDistance === 0) {
                continue;
            }
            if (abs($tokenLen - $len) <= $maxDistance) {
                $distance = levenshtein($needle, $token);
                if ($distance <= $maxDistance) {
                    $matches[$token] = 0.65 - 0.1 * ($distance - 1);
                    continue;
                }
            }
            // Tippfehler im Wortanfang ("gravl" -> "gravelbik")
            if ($tokenLen > $len) {
                $distance = levenshtein($needle, substr($token, 0, $len));
                if ($distance <= $maxDistance) {
                    $matches[$token] = 0.5 - 0.1 * ($distance - 1);
                }
            }
        }

        return $this->vocabMatchCache[$needle] = $matches;
    }

    /**
     * @param list<array<string, mixed>> $rules
     * @param list<string>               $words
     * @param list<array<string, float>> $groups
     *
     * @return list<array<string, mixed>>
     */
    private function matchRules(array $rules, array $words, array $groups, string $queryJoined): array
    {
        $alternatives = [];
        foreach ($groups as $alts) {
            foreach ($alts as $alt => $_) {
                $alternatives[(string) $alt] = true;
            }
        }

        $matches = [];
        foreach ($rules as $position => $rule) {
            $strength = 0.0;
            foreach ($rule['keys'] as $key) {
                $keyJoined = $key['j'];
                if ($keyJoined === $queryJoined) {
                    $strength = max($strength, 3.0);
                } elseif (array_diff($key['w'], $words) === [] || isset($alternatives[$keyJoined])) {
                    // Eingabe enthält den Begriff ("werkstatt termin") oder ein Synonym davon
                    $strength = max($strength, 2.5);
                } elseif (\count($words) === 1 && \count($key['w']) === 1) {
                    $word = $words[0];
                    $wordLen = \strlen($word);
                    $keyLen = \strlen($keyJoined);
                    if ($wordLen >= 5 && levenshtein($word, $keyJoined) <= ($keyLen >= 8 ? 2 : 1)) {
                        $strength = max($strength, 2.0);
                    } elseif ($wordLen >= 4 && str_starts_with($keyJoined, $word) && $wordLen >= 0.5 * $keyLen) {
                        // noch beim Tippen: "werks" zeigt schon die Werkstatt-Karte
                        $strength = max($strength, 1.5);
                    }
                }
            }
            if ($strength > 0) {
                $matches[] = $rule + ['strength' => $strength, 'order' => $position];
            }
        }

        usort($matches, static fn (array $a, array $b) => [$b['strength'], $a['order']] <=> [$a['strength'], $b['order']]);

        return $matches;
    }

    /**
     * @param array<string, array<int, float>> $inv
     */
    private function addTokens(array &$inv, int $idx, string $text, float $weight): void
    {
        if (trim($text) === '') {
            return;
        }
        foreach ($this->normalizer->tokens($text) as $token) {
            if (($inv[$token][$idx] ?? 0.0) < $weight) {
                $inv[$token][$idx] = $weight;
            }
        }
    }

    /**
     * Kommagetrennte Begriffe einzeln tokenisieren (keine Paare über Kommas hinweg).
     *
     * @param array<string, array<int, float>> $inv
     */
    private function addListTokens(array &$inv, int $idx, string $list, float $weight): void
    {
        foreach ($this->normalizer->splitList($list) as $term) {
            $this->addTokens($inv, $idx, $term, $weight);
            $joined = $this->normalizer->joined($term);
            if ($joined !== '' && ($inv[$joined][$idx] ?? 0.0) < $weight) {
                $inv[$joined][$idx] = $weight;
            }
        }
    }

    /**
     * @return list<string>
     */
    private function joinedList(string $list): array
    {
        return array_values(array_filter(array_map(
            fn (string $term) => $this->normalizer->joined($term),
            $this->normalizer->splitList($list)
        )));
    }
}
