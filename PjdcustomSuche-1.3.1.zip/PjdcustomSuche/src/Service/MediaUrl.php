<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Service;

use Shopware\Core\Content\Media\MediaEntity;

/**
 * Wählt das kleinste Vorschaubild, das noch scharf genug ist (Retina-tauglich
 * für die ca. 120 px breiten Bilder im Suchvorschlag). Spart Ladezeit.
 */
final class MediaUrl
{
    public const TARGET_WIDTH = 280;

    public static function forMedia(?MediaEntity $media, int $targetWidth = self::TARGET_WIDTH): ?string
    {
        if ($media === null) {
            return null;
        }

        $best = null;
        foreach ($media->getThumbnails() ?? [] as $thumbnail) {
            $width = $thumbnail->getWidth();
            if ($width >= $targetWidth && ($best === null || $width < $best->getWidth())) {
                $best = $thumbnail;
            }
        }

        try {
            $url = $best !== null && $best->getUrl() !== '' ? $best->getUrl() : $media->getUrl();
        } catch (\Throwable) {
            return null;
        }

        return $url !== '' ? mb_substr($url, 0, 2048) : null;
    }

    /**
     * Nur http(s)-Links und Pfade ab "/" zulassen (kein javascript: o. ä.).
     */
    public static function safeLink(?string $url): ?string
    {
        $url = trim((string) $url);
        if ($url === '') {
            return null;
        }
        if (preg_match('#^(https?://|/(?!/))#i', $url)) {
            return mb_substr($url, 0, 2048);
        }

        return null;
    }
}
