<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Service;

use Doctrine\DBAL\ArrayParameterType;
use Doctrine\DBAL\Connection;
use Psr\Log\LoggerInterface;
use Shopware\Core\Content\Category\CategoryCollection;
use Shopware\Core\Content\Category\CategoryDefinition;
use Shopware\Core\Content\Category\CategoryEntity;
use Shopware\Core\Content\Product\Aggregate\ProductVisibility\ProductVisibilityDefinition;
use Shopware\Core\Content\Product\SalesChannel\ProductAvailableFilter;
use Shopware\Core\Content\Product\SalesChannel\SalesChannelProductEntity;
use Shopware\Core\Content\Seo\SeoUrl\SeoUrlCollection;
use Shopware\Core\Defaults;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\ContainsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\MultiFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Sorting\FieldSorting;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\Currency\CurrencyFormatter;
use Shopware\Core\System\SalesChannel\Context\AbstractSalesChannelContextFactory;
use Shopware\Core\System\SalesChannel\Context\SalesChannelContextService;
use Shopware\Core\System\SalesChannel\Entity\SalesChannelRepository;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Symfony\Contracts\Cache\TagAwareCacheInterface;

/**
 * Baut den Suchindex (Tabelle pjdcustom_suche_index) je Verkaufskanal neu auf.
 *
 * Im Index stehen nur die fertigen Anzeige-Daten (Titel, Link, Bild, ab-Preis)
 * und die Rohtexte zum Durchsuchen. Die eigentliche Such-Aufbereitung
 * passiert beim Laden in SearchService, damit Verbesserungen an der Suchlogik
 * nach einem Plugin-Update sofort greifen, ohne den Index neu zu bauen.
 *
 * Läuft automatisch nach Änderungen an Produkten/Kategorien (verzögert im
 * Hintergrund), jede Nacht, per Button im Admin oder per
 * bin/console pjdcustom:suche:index
 */
class SearchIndexer
{
    public const CACHE_TAG = 'pjdcustom-suche';

    /** @var array<string, int> */
    private array $salesMap = [];
    private const PRODUCT_BATCH = 200;

    public function __construct(
        private readonly Connection $connection,
        private readonly AbstractSalesChannelContextFactory $contextFactory,
        private readonly SalesChannelRepository $productRepository,
        private readonly EntityRepository $categoryRepository,
        private readonly CurrencyFormatter $currencyFormatter,
        private readonly ConfigReader $config,
        private readonly TagAwareCacheInterface $cache,
        private readonly LoggerInterface $logger
    ) {
    }

    /**
     * Alle Storefront-Verkaufskanäle neu indexieren.
     *
     * @return array<string, array<string, mixed>> Ergebnis je Verkaufskanal-ID
     */
    public function indexAll(): array
    {
        $this->config->reset();
        $results = [];

        foreach ($this->storefrontSalesChannelIds() as $salesChannelId) {
            try {
                if (!$this->config->isActive($salesChannelId)) {
                    $this->clearSalesChannel($salesChannelId);
                    $results[$salesChannelId] = ['active' => false];
                    continue;
                }
                $results[$salesChannelId] = $this->indexSalesChannel($salesChannelId);
            } catch (\Throwable $e) {
                // Ein fehlerhafter Kanal darf den Rest nicht aufhalten; der alte Index bleibt dann erhalten.
                $this->logger->error('pjdcustom_suche: Indexierung fehlgeschlagen', [
                    'salesChannelId' => $salesChannelId,
                    'error' => $e->getMessage(),
                ]);
                $results[$salesChannelId] = ['active' => true, 'error' => $e->getMessage()];
            }
        }

        $this->cache->invalidateTags([self::CACHE_TAG]);

        return $results;
    }

    /**
     * @return array<string, mixed>
     */
    public function indexSalesChannel(string $salesChannelId): array
    {
        $start = microtime(true);
        $config = $this->config->all($salesChannelId);
        $scBytes = Uuid::fromHexToBytes($salesChannelId);
        $now = (new \DateTimeImmutable())->format(Defaults::STORAGE_DATE_TIME_FORMAT);

        // Jede Sprache, in der der Kanal ausgeliefert wird (Domains + Standardsprache),
        // bekommt einen eigenen Index. Sonst findet die Suche nichts, wenn die Domain
        // eine andere Sprache nutzt als die Standardsprache des Kanals.
        $languageIds = $this->languageIds($salesChannelId);
        $counts = ['category' => 0, 'bike' => 0, 'accessory' => 0];
        $name = $salesChannelId;
        $perLanguage = [];

        foreach ($languageIds as $languageId) {
            $context = $this->contextFactory->create(Uuid::randomHex(), $salesChannelId, [
                SalesChannelContextService::LANGUAGE_ID => $languageId,
            ]);
            $name = (string) ($context->getSalesChannel()->getTranslation('name') ?? $context->getSalesChannel()->getName() ?? $salesChannelId);

            [$categoryRows, $categories] = $this->buildCategoryRows($context, $config);
            $productRows = $this->buildProductRows($context, $config, $categories);
            $rows = array_merge($categoryRows, $productRows);
            $this->writeRows($rows, $scBytes, Uuid::fromHexToBytes($context->getLanguageId()), $now);

            $languageCounts = ['category' => 0, 'bike' => 0, 'accessory' => 0];
            foreach ($rows as $row) {
                $languageCounts[$row['type']] = ($languageCounts[$row['type']] ?? 0) + 1;
            }
            $perLanguage[$context->getLanguageId()] = $languageCounts;
            foreach ($languageCounts as $type => $count) {
                $counts[$type] = max($counts[$type] ?? 0, $count);
            }
        }

        // Einträge von Sprachen entfernen, die der Kanal nicht mehr nutzt
        $this->connection->executeStatement(
            'DELETE FROM `pjdcustom_suche_index` WHERE `sales_channel_id` = :sc AND `language_id` NOT IN (:langs)',
            ['sc' => $scBytes, 'langs' => array_map([Uuid::class, 'fromHexToBytes'], array_keys($perLanguage) ?: $languageIds)],
            ['langs' => ArrayParameterType::BINARY]
        );

        $result = [
            'active' => true,
            'salesChannelName' => $name,
            'indexedAt' => (new \DateTimeImmutable())->format(\DATE_ATOM),
            'counts' => $counts,
            'languages' => $perLanguage,
            'durationMs' => (int) round((microtime(true) - $start) * 1000),
            'pluginVersion' => $this->config->pluginVersion(),
        ];

        $this->writeState('index:' . $salesChannelId, $result);

        return $result;
    }

    /**
     * Standardsprache des Kanals plus alle Sprachen seiner Domains.
     *
     * @return list<string>
     */
    private function languageIds(string $salesChannelId): array
    {
        $ids = $this->connection->fetchFirstColumn(
            'SELECT LOWER(HEX(`language_id`)) FROM `sales_channel` WHERE `id` = :sc
             UNION
             SELECT LOWER(HEX(`language_id`)) FROM `sales_channel_domain` WHERE `sales_channel_id` = :sc',
            ['sc' => Uuid::fromHexToBytes($salesChannelId)]
        );

        return array_values(array_unique(array_filter(array_map('strval', $ids))));
    }

    /**
     * @param list<array<string, mixed>> $rows
     */
    private function writeRows(array $rows, string $scBytes, string $langBytes, string $now): void
    {
        // In einer Transaktion: Besucher sehen bis zum Commit den alten Index, nie einen leeren.
        $this->connection->transactional(function (Connection $connection) use ($rows, $scBytes, $langBytes, $now): void {
            $connection->executeStatement(
                'DELETE FROM `pjdcustom_suche_index` WHERE `sales_channel_id` = :sc AND `language_id` = :lang',
                ['sc' => $scBytes, 'lang' => $langBytes]
            );

            foreach (array_chunk($rows, 100) as $chunk) {
                $values = [];
                $params = [];
                foreach ($chunk as $i => $row) {
                    $placeholders = [];
                    $row['id'] = Uuid::randomBytes();
                    $row['sales_channel_id'] = $scBytes;
                    $row['language_id'] = $langBytes;
                    $row['created_at'] = $now;
                    foreach (self::COLUMNS as $column) {
                        $key = $column . '_' . $i;
                        $placeholders[] = ':' . $key;
                        $params[$key] = $row[$column] ?? ($column === 'sales' ? 0 : null);
                    }
                    $values[] = '(' . implode(', ', $placeholders) . ')';
                }
                $connection->executeStatement(
                    'INSERT INTO `pjdcustom_suche_index` (`' . implode('`, `', self::COLUMNS) . '`) VALUES ' . implode(', ', $values),
                    $params
                );
            }
        });
    }

    public function clearSalesChannel(string $salesChannelId): void
    {
        $this->connection->executeStatement(
            'DELETE FROM `pjdcustom_suche_index` WHERE `sales_channel_id` = :sc',
            ['sc' => Uuid::fromHexToBytes($salesChannelId)]
        );
        $this->connection->executeStatement(
            'DELETE FROM `pjdcustom_suche_state` WHERE `state_key` = :key',
            ['key' => 'index:' . $salesChannelId]
        );
    }

    /**
     * @return list<string>
     */
    public function storefrontSalesChannelIds(): array
    {
        $ids = $this->connection->fetchFirstColumn(
            'SELECT LOWER(HEX(`id`)) FROM `sales_channel` WHERE `type_id` = :type AND `active` = 1',
            ['type' => Uuid::fromHexToBytes(Defaults::SALES_CHANNEL_TYPE_STOREFRONT)]
        );

        return array_values(array_map('strval', $ids));
    }

    /**
     * @return array<string, mixed>|null
     */
    public function readState(string $key): ?array
    {
        $value = $this->connection->fetchOne(
            'SELECT `value` FROM `pjdcustom_suche_state` WHERE `state_key` = :key',
            ['key' => $key]
        );
        if (!\is_string($value)) {
            return null;
        }
        $data = json_decode($value, true);

        return \is_array($data) ? $data : null;
    }

    private const COLUMNS = [
        'id', 'sales_channel_id', 'language_id', 'type', 'entity_id', 'title', 'subtitle', 'url', 'image',
        'price', 'price_formatted', 'is_sale', 'available', 'sales', 'bike_model', 'bike_variant',
        'keywords_text', 'context_text', 'position', 'created_at',
    ];

    /**
     * @param array<string, mixed> $config
     *
     * @return array{0: list<array<string, mixed>>, 1: array<string, CategoryEntity>}
     */
    private function buildCategoryRows(SalesChannelContext $context, array $config): array
    {
        $salesChannel = $context->getSalesChannel();
        $rootIds = array_values(array_filter([
            $salesChannel->getNavigationCategoryId(),
            $config['includeFooterCategories'] ? $salesChannel->getFooterCategoryId() : null,
            $config['includeServiceCategories'] ? $salesChannel->getServiceCategoryId() : null,
        ]));

        if ($rootIds === []) {
            return [[], []];
        }

        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('active', true));
        $criteria->addFilter(new MultiFilter(MultiFilter::CONNECTION_OR, array_map(
            static fn (string $rootId) => new ContainsFilter('path', '|' . $rootId . '|'),
            $rootIds
        )));
        $criteria->addAssociation('media');
        $criteria->getAssociation('seoUrls')
            ->addFilter(new EqualsFilter('salesChannelId', $salesChannel->getId()))
            ->addFilter(new EqualsFilter('languageId', $context->getLanguageId()))
            ->addFilter(new EqualsFilter('isCanonical', true))
            ->addFilter(new EqualsFilter('isDeleted', false));
        $criteria->addSorting(new FieldSorting('level'), new FieldSorting('name'));

        /** @var CategoryCollection $collection */
        $collection = $this->categoryRepository->search($criteria, $context->getContext())->getEntities();

        /** @var array<string, CategoryEntity> $categories */
        $categories = [];
        foreach ($collection as $category) {
            $categories[$category->getId()] = $category;
        }

        $excluded = array_flip($config['excludedCategories']);
        $rows = [];
        $position = 0;

        foreach ($categories as $id => $category) {
            $ancestors = $this->ancestorIds($category);

            if (!$this->isCategoryVisible($category, $ancestors, $categories, $excluded, $rootIds, (bool) $config['includeHiddenCategories'])) {
                continue;
            }
            if ($category->getType() === CategoryDefinition::TYPE_FOLDER) {
                continue;
            }

            $url = $this->categoryUrl($category);
            if ($url === null) {
                continue;
            }

            $customFields = $category->getTranslation('customFields') ?? $category->getCustomFields() ?? [];
            $name = (string) ($category->getTranslation('name') ?? $category->getName() ?? '');
            if ($name === '') {
                continue;
            }

            $breadcrumb = [];
            foreach ($category->getPlainBreadcrumb() as $crumbId => $crumbName) {
                // nur Ebenen unterhalb der Navigations-Wurzel (nicht "Home"/"Katalog" darüber)
                if ($crumbId === $id || !isset($categories[$crumbId])) {
                    continue;
                }
                $breadcrumb[] = (string) $crumbName;
            }

            $teaser = trim((string) ($customFields[CustomFieldInstaller::FIELD_TEASER] ?? ''));
            $keywords = trim((string) ($customFields[CustomFieldInstaller::FIELD_KEYWORDS] ?? ''));
            $seoKeywords = trim((string) ($category->getTranslation('keywords') ?? ''));

            $rows[] = [
                'type' => 'category',
                'entity_id' => Uuid::fromHexToBytes($id),
                'title' => mb_substr($name, 0, 255),
                'subtitle' => mb_substr($teaser !== '' ? $teaser : implode(' › ', $breadcrumb), 0, 255) ?: null,
                'url' => $url,
                'image' => MediaUrl::forMedia($category->getMedia()),
                'price' => null,
                'price_formatted' => null,
                'is_sale' => 0,
                'available' => 1,
                'sales' => 0,
                'bike_model' => $this->modelFromCategoryName($name),
                'bike_variant' => null,
                'keywords_text' => trim($keywords . ', ' . $seoKeywords, ', '),
                'context_text' => implode(' ', $breadcrumb),
                'position' => $position++,
            ];
        }

        return [$rows, $categories];
    }

    /**
     * @param array<string, mixed> $config
     * @param array<string, CategoryEntity> $categories
     *
     * @return list<array<string, mixed>>
     */
    private function buildProductRows(SalesChannelContext $context, array $config, array $categories): array
    {
        $salesChannelId = $context->getSalesChannel()->getId();
        $accessoryIds = array_flip($config['accessoryCategories']);
        $excludedCategoryIds = array_flip($config['excludedCategories']);
        $rows = [];
        $position = 0;
        $offset = 0;

        // Verkaufte Stückzahl je Hauptprodukt (Varianten zusammengezählt) für "Bestseller"
        $this->salesMap = array_map('intval', $this->connection->fetchAllKeyValue(
            'SELECT LOWER(HEX(IFNULL(`parent_id`, `id`))), SUM(`sales`)
             FROM `product`
             WHERE `version_id` = :version
             GROUP BY IFNULL(`parent_id`, `id`)',
            ['version' => Uuid::fromHexToBytes(Defaults::LIVE_VERSION)]
        ));

        do {
            $criteria = new Criteria();
            $criteria->addFilter(new EqualsFilter('parentId', null));
            $criteria->addFilter(new ProductAvailableFilter($salesChannelId, ProductVisibilityDefinition::VISIBILITY_SEARCH));
            $criteria->addAssociation('cover.media');
            $criteria->addAssociation('manufacturer');
            $criteria->addAssociation('properties');
            $criteria->getAssociation('seoUrls')
                ->addFilter(new EqualsFilter('salesChannelId', $salesChannelId))
                ->addFilter(new EqualsFilter('languageId', $context->getLanguageId()))
                ->addFilter(new EqualsFilter('isCanonical', true))
                ->addFilter(new EqualsFilter('isDeleted', false));
            $criteria->addSorting(new FieldSorting('name'), new FieldSorting('id'));
            $criteria->setOffset($offset);
            $criteria->setLimit(self::PRODUCT_BATCH);
            $criteria->setTotalCountMode(Criteria::TOTAL_COUNT_MODE_NONE);

            $products = $this->productRepository->search($criteria, $context)->getEntities();
            $offset += self::PRODUCT_BATCH;

            /** @var SalesChannelProductEntity $product */
            foreach ($products as $product) {
                $row = $this->buildProductRow($product, $context, $config, $categories, $accessoryIds, $excludedCategoryIds);
                if ($row !== null) {
                    $row['position'] = $position++;
                    $rows[] = $row;
                }
            }
        } while ($products->count() === self::PRODUCT_BATCH);

        return $rows;
    }

    /**
     * @param array<string, mixed> $config
     * @param array<string, CategoryEntity> $categories
     * @param array<string, int> $accessoryIds
     * @param array<string, int> $excludedCategoryIds
     *
     * @return array<string, mixed>|null
     */
    private function buildProductRow(
        SalesChannelProductEntity $product,
        SalesChannelContext $context,
        array $config,
        array $categories,
        array $accessoryIds,
        array $excludedCategoryIds
    ): ?array {
        $customFields = $product->getTranslation('customFields') ?? $product->getCustomFields() ?? [];
        if (!empty($customFields[CustomFieldInstaller::FIELD_EXCLUDE])) {
            return null;
        }
        if (!$config['showOutOfStock'] && !$product->getAvailable()) {
            return null;
        }

        $name = trim((string) ($product->getTranslation('name') ?? $product->getName() ?? ''));
        if ($name === '') {
            return null;
        }

        $tree = $product->getCategoryTree() ?? [];

        // Produkt liegt ausschließlich in ausgeschlossenen Bereichen? Dann nicht anzeigen.
        if ($tree !== [] && $excludedCategoryIds !== [] && array_intersect_key(array_flip($tree), $excludedCategoryIds) !== []) {
            $outside = array_filter($tree, fn (string $id) => isset($categories[$id]) && !$this->isBelow($categories[$id], $excludedCategoryIds));
            if ($outside === []) {
                return null;
            }
        }

        $isAccessory = $accessoryIds !== [] && array_intersect_key(array_flip($tree), $accessoryIds) !== [];

        // Kategorie-Namen als Such-Kontext ("Gravel" findet auch alle GLG-Bikes)
        // und tiefste Kategorie als Unterzeile.
        $contextWords = [];
        $deepest = null;
        foreach ($tree as $categoryId) {
            if (!isset($categories[$categoryId])) {
                continue;
            }
            $category = $categories[$categoryId];
            $contextWords[] = (string) ($category->getTranslation('name') ?? $category->getName());
            if ($deepest === null || $category->getLevel() > $deepest->getLevel()) {
                $deepest = $category;
            }
        }

        $manufacturer = $product->getManufacturer();
        $manufacturerName = $manufacturer ? (string) ($manufacturer->getTranslation('name') ?? $manufacturer->getName() ?? '') : '';
        if ($manufacturerName !== '') {
            $contextWords[] = $manufacturerName;
        }

        foreach ($product->getProperties() ?? [] as $option) {
            $optionName = (string) ($option->getTranslation('name') ?? $option->getName() ?? '');
            if ($optionName !== '') {
                $contextWords[] = $optionName;
            }
        }

        $keywords = array_merge(
            $product->getTranslation('customSearchKeywords') ?? $product->getCustomSearchKeywords() ?? [],
            [(string) ($customFields[CustomFieldInstaller::FIELD_KEYWORDS] ?? ''), $product->getProductNumber()]
        );

        // ab-Preis: günstigste Variante, berechnet mit Steuern und Regeln des Verkaufskanals
        $price = null;
        $priceFormatted = null;
        $isSale = false;
        try {
            $cheapest = $product->getCalculatedCheapestPrice();
            $unit = $cheapest->getUnitPrice();
            if ($unit > 0) {
                $price = $unit;
                $priceFormatted = $this->currencyFormatter->formatCurrencyByLanguage(
                    $unit,
                    $context->getCurrency()->getIsoCode(),
                    $context->getLanguageId(),
                    $context->getContext()
                );
                $listPrice = $cheapest->getListPrice();
                $isSale = $listPrice !== null && $listPrice->getPrice() > $unit;
            }
        } catch (\Throwable) {
            // kein Preis berechenbar: Karte ohne Preis anzeigen
        }

        [$model, $variant] = $this->modelFromProductName($name);
        $teaser = trim((string) ($customFields[CustomFieldInstaller::FIELD_TEASER] ?? ''));
        $subtitle = $teaser !== '' ? $teaser : ($deepest ? (string) ($deepest->getTranslation('name') ?? $deepest->getName()) : '');

        return [
            'type' => $isAccessory ? 'accessory' : 'bike',
            'entity_id' => Uuid::fromHexToBytes($product->getId()),
            'title' => mb_substr($name, 0, 255),
            'subtitle' => $subtitle !== '' ? mb_substr($subtitle, 0, 255) : null,
            'url' => $this->seoPath($product->getSeoUrls()) ?? '/detail/' . $product->getId(),
            'image' => MediaUrl::forMedia($product->getCover()?->getMedia()),
            'price' => $price,
            'price_formatted' => $priceFormatted,
            'is_sale' => $isSale ? 1 : 0,
            'available' => $product->getAvailable() ? 1 : 0,
            'sales' => (int) ($this->salesMap[$product->getId()] ?? 0),
            'bike_model' => $isAccessory ? null : $model,
            'bike_variant' => $isAccessory ? null : $variant,
            'keywords_text' => implode(', ', array_filter(array_map('trim', array_map('strval', $keywords)))),
            'context_text' => implode(' ', array_unique($contextWords)),
        ];
    }

    /**
     * @param list<string> $ancestors
     * @param array<string, CategoryEntity> $categories
     * @param array<string, int> $excluded
     * @param list<string> $rootIds
     */
    private function isCategoryVisible(
        CategoryEntity $category,
        array $ancestors,
        array $categories,
        array $excluded,
        array $rootIds,
        bool $includeHidden
    ): bool {
        if (isset($excluded[$category->getId()])) {
            return false;
        }

        $customFields = $category->getTranslation('customFields') ?? $category->getCustomFields() ?? [];
        if (!empty($customFields[CustomFieldInstaller::FIELD_EXCLUDE])) {
            return false;
        }

        if (!$includeHidden && !$category->getVisible()) {
            return false;
        }

        // Nur Eltern-Kategorien UNTERHALB der Navigations-Wurzel prüfen.
        // Kategorien oberhalb der Wurzel (z. B. ein gemeinsamer Katalog für
        // trenga.de und fahrradcenter.de) werden nicht geladen und dürfen
        // deshalb nicht zum Ausschluss führen.
        $belowRoot = false;
        foreach ($ancestors as $ancestorId) {
            if (\in_array($ancestorId, $rootIds, true)) {
                $belowRoot = true;
                continue;
            }
            if (!$belowRoot) {
                continue;
            }
            if (isset($excluded[$ancestorId])) {
                return false;
            }
            // Eltern-Kategorie inaktiv (nicht geladen) oder ausgeblendet -> auch nicht anzeigen
            if (!isset($categories[$ancestorId])) {
                return false;
            }
            if (!$includeHidden && !$categories[$ancestorId]->getVisible()) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param array<string, int> $excluded
     */
    private function isBelow(CategoryEntity $category, array $excluded): bool
    {
        if (isset($excluded[$category->getId()])) {
            return true;
        }
        foreach ($this->ancestorIds($category) as $ancestorId) {
            if (isset($excluded[$ancestorId])) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return list<string>
     */
    private function ancestorIds(CategoryEntity $category): array
    {
        $path = $category->getPath();
        if ($path === null || $path === '') {
            return [];
        }

        return array_values(array_filter(explode('|', $path)));
    }

    private function categoryUrl(CategoryEntity $category): ?string
    {
        if ($category->getType() === CategoryDefinition::TYPE_LINK) {
            $linkType = $category->getLinkType();
            $target = $category->getInternalLink();

            return match ($linkType) {
                CategoryDefinition::LINK_TYPE_EXTERNAL => MediaUrl::safeLink((string) $category->getTranslation('externalLink') ?: (string) $category->getExternalLink()),
                CategoryDefinition::LINK_TYPE_CATEGORY => $target ? '/navigation/' . $target : null,
                CategoryDefinition::LINK_TYPE_PRODUCT => $target ? '/detail/' . $target : null,
                CategoryDefinition::LINK_TYPE_LANDING_PAGE => $target ? '/landingPage/' . $target : null,
                default => null,
            };
        }

        return $this->seoPath($category->getSeoUrls()) ?? '/navigation/' . $category->getId();
    }

    private function seoPath(?SeoUrlCollection $seoUrls): ?string
    {
        if ($seoUrls === null) {
            return null;
        }
        foreach ($seoUrls as $seoUrl) {
            $path = $seoUrl->getSeoPathInfo();
            if ($path !== '') {
                return '/' . ltrim($path, '/');
            }
        }

        return null;
    }



    /**
     * "TRENGA GLG 9.0" -> ["GLG", "GLG 9.0"]
     *
     * @return array{0: string|null, 1: string|null}
     */
    private function modelFromProductName(string $name): array
    {
        if (preg_match('/\b([A-Z]{2,5})\s?(\d{1,2}(?:[.,]\d{1,2})?)\b/u', $name, $match)) {
            return [$match[1], $match[1] . ' ' . str_replace(',', '.', $match[2])];
        }

        return [null, null];
    }

    private function modelFromCategoryName(string $name): ?string
    {
        if (preg_match('/^([A-Z]{2,5})\b/u', trim($name), $match)) {
            return $match[1];
        }

        return null;
    }

    /**
     * @param array<string, mixed> $value
     */
    private function writeState(string $key, array $value): void
    {
        $this->connection->executeStatement(
            'INSERT INTO `pjdcustom_suche_state` (`state_key`, `value`, `updated_at`) VALUES (:key, :value, :now)
             ON DUPLICATE KEY UPDATE `value` = VALUES(`value`), `updated_at` = VALUES(`updated_at`)',
            [
                'key' => $key,
                'value' => json_encode($value, \JSON_UNESCAPED_UNICODE),
                'now' => (new \DateTimeImmutable())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ]
        );
    }
}
