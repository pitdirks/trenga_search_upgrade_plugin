<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Service;

use Pjdcustom\Suche\Message\ReindexMessage;
use Psr\Cache\CacheItemPoolInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Messenger\Envelope;
use Symfony\Component\Messenger\MessageBusInterface;
use Symfony\Component\Messenger\Stamp\DelayStamp;

/**
 * Plant einen Neuaufbau des Index im Hintergrund.
 *
 * Bündelt viele Änderungen (z. B. Import von 200 Produkten) zu EINEM Auftrag
 * und startet ihn mit 30 Sekunden Verzögerung, damit Shopware vorher
 * SEO-URLs und günstigste Preise aktualisiert hat.
 */
class ReindexScheduler
{
    private const PENDING_KEY = 'pjdcustom_suche_reindex_pending';
    private const DELAY_MS = 30000;
    private const PENDING_TTL = 180;

    private bool $scheduledInThisRequest = false;

    public function __construct(
        private readonly MessageBusInterface $bus,
        private readonly CacheItemPoolInterface $cache,
        private readonly LoggerInterface $logger
    ) {
    }

    public function schedule(): void
    {
        if ($this->scheduledInThisRequest) {
            return;
        }
        $this->scheduledInThisRequest = true;

        try {
            $item = $this->cache->getItem(self::PENDING_KEY);
            if ($item->isHit()) {
                return;
            }
            $item->set(time());
            $item->expiresAfter(self::PENDING_TTL);
            $this->cache->save($item);

            $this->bus->dispatch(new Envelope(new ReindexMessage(), [new DelayStamp(self::DELAY_MS)]));
        } catch (\Throwable $e) {
            // Darf das Speichern im Admin nie blockieren; der nächtliche Lauf holt es nach.
            $this->logger->warning('pjdcustom_suche: Neuaufbau konnte nicht eingeplant werden', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Zwischen zwei Anfragen eines langlaufenden Workers zurücksetzen.
     */
    public function reset(): void
    {
        $this->scheduledInThisRequest = false;
    }

    public function clearPending(): void
    {
        try {
            $this->cache->deleteItem(self::PENDING_KEY);
        } catch (\Throwable) {
        }
        $this->scheduledInThisRequest = false;
    }
}
