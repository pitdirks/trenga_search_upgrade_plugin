<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Subscriber;

use Pjdcustom\Suche\Service\ConfigReader;
use Shopware\Storefront\Event\StorefrontRenderEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

/**
 * Gibt dem Template die Einstellungen und Texte für das Such-Overlay mit.
 * Ist die Suche im Verkaufskanal aus, wird nichts übergeben und das
 * Template bindet nichts ein.
 */
class StorefrontSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private readonly ConfigReader $config,
        private readonly UrlGeneratorInterface $router
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [StorefrontRenderEvent::class => 'onRender'];
    }

    public function onRender(StorefrontRenderEvent $event): void
    {
        $request = $event->getRequest();
        if ($request->isXmlHttpRequest()) {
            return;
        }

        $salesChannelId = $event->getSalesChannelContext()->getSalesChannelId();
        if (!$this->config->isActive($salesChannelId)) {
            return;
        }

        $config = $this->config->all($salesChannelId);

        try {
            $endpoint = $this->router->generate('frontend.pjdcustom.suche.suggest');
            $searchUrl = $this->router->generate('frontend.search.page');
        } catch (\Throwable) {
            return;
        }

        $event->setParameter('pjdcustomSuche', [
            'version' => $this->config->pluginVersion(),
            'endpoint' => $endpoint,
            'searchUrl' => $searchUrl,
            'inputSelector' => $config['inputSelector'],
            'mobileTriggerSelector' => $config['mobileTriggerSelector'],
            'mobileBreakpoint' => (int) $config['mobileBreakpoint'],
            'minChars' => max(1, (int) $config['minChars']),
            'showImages' => $config['showImages'],
            'showPriceDesktop' => $config['showPriceDesktop'],
            'showPriceMobile' => $config['showPriceMobile'],
            'showSaleBadge' => $config['showSaleBadge'],
            'showQuickLinks' => $config['showQuickLinks'],
            'showAllResultsLink' => $config['showAllResultsLink'],
            'tracking' => $config['trackingEnabled'],
            'debug' => $config['debug'],
            'texts' => [
                'placeholder' => $config['textPlaceholder'],
                'mobileTitle' => $config['textMobileTitle'],
                'close' => $config['textClose'],
                'clear' => $config['textClear'],
                'categories' => $config['textGroupCategories'],
                'bikes' => $config['textGroupBikes'],
                'accessories' => $config['textGroupAccessories'],
                'entries' => $config['textGroupEntries'],
                'quickLinks' => $config['textQuickLinks'],
                'priceFrom' => $config['textPriceFrom'],
                'sale' => $config['textSale'],
                'highlightButton' => $config['textHighlightButton'],
                'noResultsTitle' => $config['textNoResultsTitle'],
                'noResultsText' => $config['textNoResultsText'],
                'allResults' => $config['textAllResults'],
                'resultsCount' => $config['textResultsCount'],
                'recommendations' => $config['textRecommendations'],
            ],
        ]);
    }
}
