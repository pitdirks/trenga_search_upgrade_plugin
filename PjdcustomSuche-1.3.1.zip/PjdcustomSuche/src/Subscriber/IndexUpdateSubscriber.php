<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Subscriber;

use Pjdcustom\Suche\Service\ConfigReader;
use Pjdcustom\Suche\Service\ReindexScheduler;
use Pjdcustom\Suche\Service\SearchIndexer;
use Shopware\Core\Framework\DataAbstractionLayer\Event\EntityWrittenEvent;
use Shopware\Core\System\SystemConfig\Event\SystemConfigChangedEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;

/**
 * Hält die Suche aktuell:
 *   - Produkte, Preise, Sichtbarkeit, Kategorien, SEO-URLs geändert
 *       -> Index wird im Hintergrund neu gebaut (gebündelt, verzögert)
 *   - Direktlinks, Synonyme, Einträge im Admin gespeichert
 *       -> Such-Cache wird sofort geleert (kein Neuaufbau nötig)
 *   - Plugin-Einstellungen geändert -> Cache leeren, ggf. Index neu bauen
 */
class IndexUpdateSubscriber implements EventSubscriberInterface
{
    private const REINDEX_ENTITIES = [
        'product', 'product_translation', 'product_price', 'product_visibility', 'product_category',
        'product_media', 'product_property', 'product_manufacturer_translation',
        'category', 'category_translation', 'seo_url',
    ];

    private const CACHE_ENTITIES = [
        'pjdcustom_suche_rule', 'pjdcustom_suche_synonym', 'pjdcustom_suche_entry',
    ];

    private const REINDEX_CONFIG_KEYS = [
        'active', 'includeFooterCategories', 'includeServiceCategories', 'includeHiddenCategories',
        'excludedCategories', 'accessoryCategories', 'showOutOfStock',
    ];

    public function __construct(
        private readonly ReindexScheduler $scheduler,
        private readonly TagAwareCacheInterface $cache
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        $events = [SystemConfigChangedEvent::class => 'onConfigChanged'];

        foreach (self::REINDEX_ENTITIES as $entity) {
            $events[$entity . '.written'] = 'onIndexRelevantChange';
            $events[$entity . '.deleted'] = 'onIndexRelevantChange';
        }
        foreach (self::CACHE_ENTITIES as $entity) {
            $events[$entity . '.written'] = 'onSearchContentChange';
            $events[$entity . '.deleted'] = 'onSearchContentChange';
        }

        return $events;
    }

    public function onIndexRelevantChange(EntityWrittenEvent $event): void
    {
        if ($event->getIds() === []) {
            return;
        }
        $this->scheduler->schedule();
    }

    public function onSearchContentChange(EntityWrittenEvent $event): void
    {
        $this->invalidate();
    }

    public function onConfigChanged(SystemConfigChangedEvent $event): void
    {
        $key = $event->getKey();
        if (!str_starts_with($key, ConfigReader::DOMAIN)) {
            return;
        }

        $this->invalidate();

        if (\in_array(substr($key, \strlen(ConfigReader::DOMAIN)), self::REINDEX_CONFIG_KEYS, true)) {
            $this->scheduler->schedule();
        }
    }

    private function invalidate(): void
    {
        try {
            $this->cache->invalidateTags([SearchIndexer::CACHE_TAG]);
        } catch (\Throwable) {
            // Cache läuft spätestens nach 24 h ab
        }
    }
}
