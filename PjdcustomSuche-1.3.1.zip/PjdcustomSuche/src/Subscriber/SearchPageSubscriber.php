<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Subscriber;

use Pjdcustom\Suche\Service\ConfigReader;
use Pjdcustom\Suche\Service\SearchService;
use Psr\Log\LoggerInterface;
use Shopware\Core\Framework\Struct\ArrayStruct;
use Shopware\Storefront\Framework\Routing\RequestTransformer;
use Shopware\Storefront\Page\Search\SearchPageLoadedEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Keine-Treffer-Bereich auf der Shopware-Ergebnisseite:
 * Findet Shopware zu einem Begriff nichts, bekommt die Seite Produkte
 * (Auswahl und/oder Bestseller) und Schnelllinks mit. Ausgegeben wird das
 * in page/search/index.html.twig dieses Plugins.
 *
 * Fehler hier dürfen die Ergebnisseite nie stören, deshalb alles im try.
 */
class SearchPageSubscriber implements EventSubscriberInterface
{
    public const EXTENSION = 'pjdcustomSucheNoResults';

    public function __construct(
        private readonly ConfigReader $config,
        private readonly SearchService $searchService,
        private readonly LoggerInterface $logger
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [SearchPageLoadedEvent::class => 'onSearchPageLoaded'];
    }

    public function onSearchPageLoaded(SearchPageLoadedEvent $event): void
    {
        $context = $event->getSalesChannelContext();
        $salesChannelId = $context->getSalesChannelId();

        try {
            if (!$this->config->isActive($salesChannelId)) {
                return;
            }
            $config = $this->config->all($salesChannelId);
            if (!$config['noResultsEnabled']) {
                return;
            }

            $page = $event->getPage();
            if ($page->getListing()->getTotal() > 0) {
                return;
            }

            $baseUrl = (string) $event->getRequest()->attributes->get(RequestTransformer::STOREFRONT_URL, '');
            $items = $this->searchService->recommendations($context, $baseUrl);
            $quick = $config['noResultsShowQuickLinks'] ? $this->searchService->quickLinks($context, $baseUrl) : [];

            if ($items === [] && $quick === []) {
                return;
            }

            $page->addExtension(self::EXTENSION, new ArrayStruct([
                'title' => $config['textNoResultsPageTitle'],
                'text' => $config['textNoResultsPageText'],
                'quickTitle' => $config['textNoResultsPageQuickLinks'],
                'items' => $items,
                'quick' => $quick,
                'hideNotice' => (bool) $config['noResultsHideShopwareNotice'],
                'showPriceDesktop' => (bool) $config['showPriceDesktop'],
                'showPriceMobile' => (bool) $config['showPriceMobile'],
                'showImages' => (bool) $config['showImages'],
                'showSaleBadge' => (bool) $config['showSaleBadge'],
                'priceFrom' => $config['textPriceFrom'],
                'saleText' => $config['textSale'],
            ]));
        } catch (\Throwable $e) {
            $this->logger->warning('pjdcustom_suche: Keine-Treffer-Bereich konnte nicht geladen werden', ['error' => $e->getMessage()]);
        }
    }
}
