<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Message;

use Pjdcustom\Suche\Service\ReindexScheduler;
use Pjdcustom\Suche\Service\SearchIndexer;
use Symfony\Component\Messenger\Attribute\AsMessageHandler;

#[AsMessageHandler]
class ReindexMessageHandler
{
    public function __construct(
        private readonly SearchIndexer $indexer,
        private readonly ReindexScheduler $scheduler
    ) {
    }

    public function __invoke(ReindexMessage $message): void
    {
        // Ab jetzt dürfen neue Änderungen wieder einen Auftrag auslösen
        $this->scheduler->clearPending();
        $this->indexer->indexAll();
    }
}
