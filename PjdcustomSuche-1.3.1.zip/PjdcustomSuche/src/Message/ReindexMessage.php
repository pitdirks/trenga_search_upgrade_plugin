<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Message;

use Shopware\Core\Framework\MessageQueue\AsyncMessageInterface;

/**
 * Auftrag "Suchindex neu aufbauen", läuft im Hintergrund (Message Queue).
 */
class ReindexMessage implements AsyncMessageInterface
{
}
