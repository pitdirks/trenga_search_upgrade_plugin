/*!
 * pjdcustom_suche – Such-Overlay für trenga.de
 * Entwickelt von Pit Dirks. Ohne Framework, ohne Abhängigkeiten.
 *
 * Ablauf
 *   Desktop:  Fokus/Tippen im Header-Suchfeld -> Dropdown unter dem Feld
 *   Mobil:    Lupe oder Suchfeld antippen      -> Vollbild-Overlay
 *   Enter:    Direktlink / passende Kategorie / einziger Treffer, sonst Shopware-Ergebnisseite
 *
 * Sicherheit
 *   Antwortet der Server nicht oder mit Fehler, schaltet sich das Skript für
 *   diesen Seitenaufruf ab und die normale Shopware-Suche übernimmt wieder.
 *
 * Tracking (dataLayer, Schema pjdcustom_interaction, element = "suche")
 *   view    target dropdown | overlay     einmal pro Seitenaufruf beim ersten Öffnen
 *   view    target no_results             Suche ohne Treffer, label = Suchbegriff
 *   view    target no_results_page        Ergebnisseite mit Keine-Treffer-Bereich, label = Suchbegriff
 *   select  target kategorie | bike | zubehoer | standort | service | eintrag |
 *                  direktlink | schnelllink | empfehlung | ergebnisseite
 *                                         label = "Suchbegriff > Treffer"
 *   submit  target direktlink | kategorie | treffer | ergebnisseite
 *                                         label = Suchbegriff
 */
(function () {
    'use strict';

    var configEl = document.getElementById('pjdcustom-suche-config');
    if (!configEl || !window.fetch || !window.Map || !window.AbortController || window.__pjdcustomSuche) {
        return;
    }
    window.__pjdcustomSuche = true;

    var opts;
    try {
        opts = JSON.parse(configEl.getAttribute('data-options') || '{}');
    } catch (e) {
        return;
    }
    if (!opts.endpoint || !opts.inputSelector) {
        return;
    }

    var T = opts.texts || {};
    var DEBOUNCE_MS = 120;
    var LOADING_DELAY_MS = 180;
    var SUBMIT_TIMEOUT_MS = 900;
    var NO_RESULTS_DELAY_MS = 1200;
    var CACHE_LIMIT = 60;

    var state = {
        broken: false,
        surface: null,          // 'dropdown' | 'overlay' | null
        activeInput: null,      // Eingabefeld, in dem gerade gesucht wird
        sourceInput: null,      // Original-Suchfeld des Themes
        query: '',
        response: null,
        activeIndex: -1,
        seq: 0,
        controller: null,
        debounceTimer: 0,
        loadingTimer: 0,
        noResultsTimer: 0,
        viewed: {},
        noResultsSent: {},
        historyPushed: false,
        lastTrigger: null
    };

    var cache = new Map();
    var pending = new Map();
    var uid = 0;

    function log() {
        if (opts.debug && window.console) {
            var args = Array.prototype.slice.call(arguments);
            args.unshift('[pjdcustom_suche]');
            console.info.apply(console, args);
        }
    }

    /* ================================================================
       Tracking
       ================================================================ */

    function cleanTerm(term) {
        var t = String(term || '').trim().replace(/\s+/g, ' ').toLowerCase();
        if (!t) {
            return undefined;
        }
        // Keine personenbezogenen Daten ins Tracking (E-Mail, Telefonnummer, lange Ziffernfolgen)
        if (t.indexOf('@') !== -1 || /\d{5,}/.test(t.replace(/[\s\-\/().+]/g, ''))) {
            return undefined;
        }
        return t.slice(0, 100);
    }

    function track(action, target, label, bikeModel, bikeVariant) {
        if (!opts.tracking) {
            return;
        }
        var event = {
            event: 'pjdcustom_interaction',
            element: 'suche',
            action: action,
            target: target,
            label: label ? String(label).slice(0, 100) : undefined,
            bike_model: bikeModel || undefined,
            bike_variant: bikeVariant || undefined,
            element_version: opts.version || undefined
        };
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push(event);
        log('tracking', event);
    }

    function trackView(surface) {
        if (state.viewed[surface]) {
            return;
        }
        state.viewed[surface] = true;
        track('view', surface);
    }

    function scheduleNoResults(query, response) {
        clearTimeout(state.noResultsTimer);
        if (!response || response.total > 0) {
            return;
        }
        var term = cleanTerm(query);
        if (!term || state.noResultsSent[term]) {
            return;
        }
        state.noResultsTimer = setTimeout(function () {
            if (cleanTerm(state.query) !== term) {
                return;
            }
            state.noResultsSent[term] = true;
            track('view', 'no_results', term);
        }, NO_RESULTS_DELAY_MS);
    }

    /* ================================================================
       Daten
       ================================================================ */

    function cacheKey(query) {
        return query.trim().toLowerCase().replace(/\s+/g, ' ');
    }

    function remember(key, data) {
        if (cache.size >= CACHE_LIMIT) {
            cache.delete(cache.keys().next().value);
        }
        cache.set(key, data);
    }

    function fetchResults(query) {
        var key = cacheKey(query);
        if (cache.has(key)) {
            return Promise.resolve(cache.get(key));
        }
        if (pending.has(key)) {
            return pending.get(key);
        }

        // Ältere, noch laufende Anfrage abbrechen (außer den Schnelllinks)
        if (state.controller && key !== '') {
            state.controller.abort();
        }
        var controller = new AbortController();
        if (key !== '') {
            state.controller = controller;
        }

        var started = Date.now();
        var request = fetch(opts.endpoint + '?q=' + encodeURIComponent(key), {
            method: 'GET',
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' },
            signal: controller.signal
        }).then(function (res) {
            if (!res.ok) {
                throw new Error('HTTP ' + res.status);
            }
            return res.json();
        }).then(function (data) {
            if (!data || data.fallback) {
                throw new Error('fallback');
            }
            log('Antwort für "' + key + '"', (Date.now() - started) + ' ms gesamt,', (data.ms || 0) + ' ms Server', data);
            remember(key, data);
            return data;
        });

        pending.set(key, request);
        request.then(function () { pending.delete(key); }, function (err) {
            pending.delete(key);
            if (!err || err.name !== 'AbortError') {
                disable(err);
            }
        });

        return request;
    }

    function disable(err) {
        if (state.broken) {
            return;
        }
        state.broken = true;
        log('Suche abgeschaltet, Shopware-Suche übernimmt', err);
        closeAll(false);
        document.documentElement.classList.remove('pjdcs-enabled');
    }

    /* ================================================================
       Hilfen
       ================================================================ */

    function el(tag, className, text) {
        var node = document.createElement(tag);
        if (className) {
            node.className = className;
        }
        if (text !== undefined && text !== null) {
            node.textContent = text;
        }
        return node;
    }

    function isMobile() {
        return window.innerWidth < (opts.mobileBreakpoint || 1024);
    }

    function matchesInput(node) {
        if (!node || !node.matches || (node.classList && node.classList.contains('pjdcs-ov-input'))) {
            return false;
        }
        try {
            return node.matches(opts.inputSelector);
        } catch (e) {
            return false;
        }
    }

    function fillTerm(text, term, count) {
        return String(text || '').replace(/%term%/g, term).replace(/%count%/g, count);
    }

    function searchPageUrl(query) {
        var base = opts.searchUrl || '/search';
        return base + (base.indexOf('?') === -1 ? '?' : '&') + 'search=' + encodeURIComponent(query.trim());
    }

    /** Suchbegriff im Titel hervorheben (nur Text-Knoten, kein HTML aus Daten) */
    function highlight(node, text, query) {
        var words = query.trim().toLowerCase().split(/\s+/).filter(function (w) { return w.length >= 2; });
        if (!words.length) {
            node.textContent = text;
            return;
        }
        var lower = text.toLowerCase();
        var ranges = [];
        words.forEach(function (word) {
            var idx = lower.indexOf(word);
            if (idx !== -1) {
                ranges.push([idx, idx + word.length]);
            }
        });
        ranges.sort(function (a, b) { return a[0] - b[0]; });
        var pos = 0;
        ranges.forEach(function (range) {
            if (range[0] < pos) {
                return;
            }
            if (range[0] > pos) {
                node.appendChild(document.createTextNode(text.slice(pos, range[0])));
            }
            node.appendChild(el('mark', null, text.slice(range[0], range[1])));
            pos = range[1];
        });
        if (pos < text.length) {
            node.appendChild(document.createTextNode(text.slice(pos)));
        }
    }

    function image(src, className) {
        var wrap = el('span', className);
        if (!opts.showImages || !src) {
            wrap.classList.add('pjdcs-noimg');
            return wrap;
        }
        var img = new Image();
        img.alt = '';
        img.loading = 'lazy';
        img.decoding = 'async';
        img.addEventListener('error', function () {
            wrap.classList.add('pjdcs-noimg');
            if (img.parentNode) {
                img.parentNode.removeChild(img);
            }
        });
        img.src = src;
        wrap.appendChild(img);
        return wrap;
    }

    /* ================================================================
       Darstellung
       ================================================================ */

    function option(link, data, target) {
        link.setAttribute('role', 'option');
        link.id = 'pjdcs-opt-' + (++uid);
        link.setAttribute('data-pjdcs-target', target);
        link.setAttribute('data-pjdcs-title', data.title || '');
        if (data.track && data.track.bike_model) {
            link.setAttribute('data-pjdcs-bm', data.track.bike_model);
        }
        if (data.track && data.track.bike_variant) {
            link.setAttribute('data-pjdcs-bv', data.track.bike_variant);
        }
        return link;
    }

    function renderHighlight(item, query) {
        var link = option(el('a', 'pjdcs-highlight'), item, 'direktlink');
        link.href = item.url;
        if (item.img && opts.showImages) {
            link.classList.add('has-img');
            link.appendChild(image(item.img, 'pjdcs-highlight-img'));
        }
        var body = el('span', 'pjdcs-highlight-body');
        var title = el('span', 'pjdcs-highlight-title');
        highlight(title, item.title, query);
        body.appendChild(title);
        if (item.text) {
            body.appendChild(el('span', 'pjdcs-highlight-text', item.text));
        }
        link.appendChild(body);
        link.appendChild(el('span', 'pjdcs-btn', item.button || T.highlightButton));
        return link;
    }

    function renderCard(item, query) {
        var link = option(el('a', 'pjdcs-card'), item, item.track ? item.track.target : 'bike');
        link.href = item.url;
        var media = image(item.img, 'pjdcs-card-img');
        if (opts.showSaleBadge && item.sale && T.sale) {
            media.appendChild(el('span', 'pjdcs-badge', T.sale));
        }
        link.appendChild(media);
        var title = el('span', 'pjdcs-card-title');
        highlight(title, item.title, query);
        link.appendChild(title);
        var showPrice = state.surface === 'overlay' ? opts.showPriceMobile : opts.showPriceDesktop;
        if (showPrice && item.price) {
            link.appendChild(el('span', 'pjdcs-card-price', (T.priceFrom ? T.priceFrom + ' ' : '') + item.price));
        } else if (item.sub) {
            link.appendChild(el('span', 'pjdcs-card-sub', item.sub));
        }
        return link;
    }

    function renderRow(item, query) {
        var link = option(el('a', 'pjdcs-row pjdcs-row--' + (item.track ? item.track.target : 'eintrag')), item, item.track ? item.track.target : 'eintrag');
        link.href = item.url;
        link.appendChild(image(item.img, 'pjdcs-row-img'));
        var body = el('span', 'pjdcs-row-body');
        var title = el('span', 'pjdcs-row-title');
        highlight(title, item.title, query);
        body.appendChild(title);
        if (item.sub) {
            body.appendChild(el('span', 'pjdcs-row-sub', item.sub));
        }
        link.appendChild(body);
        link.appendChild(el('span', 'pjdcs-row-arrow'));
        return link;
    }

    function renderChip(item) {
        var target = item.track ? item.track.target : 'schnelllink';
        var link = option(el('a', 'pjdcs-chip'), item, target);
        link.href = item.url;
        link.appendChild(el('span', 'pjdcs-chip-label', item.title));
        return link;
    }

    function renderGroup(container, key, label, items, renderer, query, layout) {
        var group = el('div', 'pjdcs-group pjdcs-group--' + key);
        group.setAttribute('role', 'group');
        var headingId = 'pjdcs-h-' + (++uid);
        var heading = el('div', 'pjdcs-group-title', label);
        heading.id = headingId;
        group.setAttribute('aria-labelledby', headingId);
        group.appendChild(heading);
        var list = el('div', 'pjdcs-' + layout);
        items.forEach(function (item) {
            list.appendChild(renderer(item, query));
        });
        group.appendChild(list);
        container.appendChild(group);
    }

    var GROUPS = {
        categories: { label: 'categories', renderer: renderRow, layout: 'rows' },
        bikes: { label: 'bikes', renderer: renderCard, layout: 'cards' },
        accessories: { label: 'accessories', renderer: renderCard, layout: 'cards' },
        entries: { label: 'entries', renderer: renderRow, layout: 'rows' }
    };

    function render(container, data, query) {
        container.textContent = '';
        state.activeIndex = -1;
        if (state.activeInput) {
            state.activeInput.removeAttribute('aria-activedescendant');
        }

        var term = query.trim();
        var hasQuery = term.length >= (opts.minChars || 2);

        (data.highlights || []).forEach(function (item) {
            container.appendChild(renderHighlight(item, term));
        });

        (data.groups || []).forEach(function (group) {
            var def = GROUPS[group.key];
            if (def && group.items && group.items.length) {
                renderGroup(container, group.key, T[def.label], group.items, def.renderer, term, def.layout);
            }
        });

        if (hasQuery && data.total === 0) {
            var empty = el('div', 'pjdcs-empty');
            empty.appendChild(el('p', 'pjdcs-empty-title', T.noResultsTitle));
            if (data.quick && data.quick.length && T.noResultsText) {
                empty.appendChild(el('p', 'pjdcs-empty-text', T.noResultsText));
            }
            container.appendChild(empty);
        }

        var hasQuick = opts.showQuickLinks && data.quick && data.quick.length;
        var hasRecommendations = data.recommendations && data.recommendations.length;

        if (!hasQuery) {
            // Leeres Suchfeld: kompakt. Oben Themen (z. B. Probefahrt, Werkstatt-Termin) als Buttons,
            // darunter genau EINE Reihe Produkte.
            if (hasQuick) {
                renderGroup(container, 'quick', T.quickLinks, data.quick, renderChip, '', 'chips');
            }
            if (hasRecommendations) {
                renderGroup(container, 'recommendations', T.recommendations, data.recommendations, renderCard, '', 'cards pjdcs-cards--row');
            }
        } else if (data.total === 0) {
            if (hasRecommendations) {
                renderGroup(container, 'recommendations', T.recommendations, data.recommendations, renderCard, '', 'cards');
            }
            if (hasQuick) {
                renderGroup(container, 'quick', T.quickLinks, data.quick, renderRow, '', 'rows');
            }
        }

        if (opts.showAllResultsLink && hasQuery && data.groups && data.groups.length) {
            var all = el('a', 'pjdcs-all', fillTerm(T.allResults, term, data.total));
            option(all, { title: 'ergebnisseite' }, 'ergebnisseite');
            all.href = searchPageUrl(term);
            container.appendChild(all);
        }

        announce(hasQuery ? fillTerm(T.resultsCount, term, data.total || 0) : '');
    }

    function announce(text) {
        var live = document.getElementById('pjdcs-live');
        if (!live) {
            live = el('div', 'pjdcs-sr');
            live.id = 'pjdcs-live';
            live.setAttribute('aria-live', 'polite');
            live.setAttribute('role', 'status');
            document.body.appendChild(live);
        }
        live.textContent = text;
    }

    function setLoading(on) {
        clearTimeout(state.loadingTimer);
        var target = state.surface === 'overlay' ? overlay.root : dropdown.root;
        if (!target) {
            return;
        }
        if (!on) {
            target.classList.remove('is-loading');
            return;
        }
        state.loadingTimer = setTimeout(function () {
            target.classList.add('is-loading');
        }, LOADING_DELAY_MS);
    }

    /* ================================================================
       Desktop-Dropdown
       ================================================================ */

    var dropdown = { root: null, list: null, frame: 0, follow: 0, observer: null, frozen: false };

    function ensureDropdown() {
        if (dropdown.root) {
            return;
        }
        dropdown.root = el('div', 'pjdcs-dropdown');
        dropdown.root.hidden = true;
        dropdown.list = el('div', 'pjdcs-results');
        dropdown.list.id = 'pjdcs-dropdown-list';
        dropdown.list.setAttribute('role', 'listbox');
        dropdown.root.appendChild(dropdown.list);
        document.body.appendChild(dropdown.root);

        // Klick ins Dropdown soll den Fokus nicht aus dem Suchfeld nehmen
        dropdown.root.addEventListener('mousedown', function (e) {
            if (!e.target.closest('a')) {
                e.preventDefault();
            } else {
                // Ab dem Klick auf einen Treffer bleibt das Dropdown stehen, bis die neue Seite lädt
                dropdown.frozen = true;
            }
        });

        // Das Theme klappt das Suchfeld bei jedem Klick "außerhalb" wieder ein.
        // Klicks im Dropdown dürfen deshalb nicht bis zum Dokument durchgereicht werden.
        dropdown.root.addEventListener('click', onResultClick);
        dropdown.root.addEventListener('click', stopBubbling);
        dropdown.root.addEventListener('touchstart', stopBubbling, { passive: true });
    }

    function stopBubbling(e) {
        e.stopPropagation();
    }

    function positionDropdown() {
        if (!dropdown.root || dropdown.root.hidden || !state.activeInput || dropdown.frozen) {
            return;
        }
        var anchor = state.activeInput.closest('form') || state.activeInput;
        var rect = anchor.getBoundingClientRect();
        if (!rect.width && !rect.height) {
            closeDropdown();
            return;
        }
        // Genau so breit wie das (aufgeklappte) Suchfeld, direkt darunter
        var vw = document.documentElement.clientWidth;
        var vh = window.innerHeight;
        var width = Math.min(Math.max(rect.width, 320), vw - 24);
        var left = Math.min(Math.max(12, rect.left), vw - width - 12);
        var top = rect.bottom + 8;
        var style = dropdown.root.style;
        style.top = top + 'px';
        style.left = left + 'px';
        style.width = width + 'px';
        style.maxHeight = Math.max(240, vh - top - 16) + 'px';
        dropdown.root.classList.toggle('is-narrow', width < 560);
    }

    /**
     * Das Theme klappt das Suchfeld beim Klick animiert auf (ca. 0,3 s).
     * Während dieser Zeit und bei jeder späteren Größenänderung folgt das
     * Dropdown dem Feld, damit es nie an der alten Position stehen bleibt.
     */
    function followAnchor(duration) {
        var until = Date.now() + duration;
        var lastWidth = -1;
        var stableFrames = 0;
        cancelAnimationFrame(dropdown.follow);
        var step = function () {
            positionDropdown();
            var anchor = state.activeInput && (state.activeInput.closest('form') || state.activeInput);
            var width = anchor ? Math.round(anchor.getBoundingClientRect().width) : 0;
            stableFrames = width === lastWidth ? stableFrames + 1 : 0;
            lastWidth = width;
            // Erst einblenden, wenn das Feld 3 Frames lang seine Breite hält (Animation des Themes fertig)
            if (stableFrames >= 3 || Date.now() >= until) {
                reveal();
            }
            if (Date.now() < until && dropdown.root && !dropdown.root.hidden) {
                dropdown.follow = requestAnimationFrame(step);
            }
        };
        dropdown.follow = requestAnimationFrame(step);
    }

    function reveal() {
        if (dropdown.root && dropdown.root.classList.contains('is-settling')) {
            dropdown.root.classList.remove('is-settling');
        }
    }

    function observeAnchor() {
        var anchor = state.activeInput && (state.activeInput.closest('form') || state.activeInput);
        if (!anchor || !window.ResizeObserver) {
            return;
        }
        if (!dropdown.observer) {
            dropdown.observer = new ResizeObserver(function () {
                requestPosition();
            });
        }
        dropdown.observer.disconnect();
        dropdown.observer.observe(anchor);
    }

    function onTransitionEnd() {
        requestPosition();
    }

    function requestPosition() {
        if (dropdown.frame) {
            return;
        }
        dropdown.frame = requestAnimationFrame(function () {
            dropdown.frame = 0;
            positionDropdown();
        });
    }

    function openDropdown(input) {
        ensureDropdown();
        state.surface = 'dropdown';
        state.activeInput = input;
        dropdown.frozen = false;
        input.setAttribute('aria-controls', dropdown.list.id);
        if (dropdown.root.hidden) {
            dropdown.root.classList.add('is-settling');
            dropdown.root.hidden = false;
            input.setAttribute('aria-expanded', 'true');
            window.addEventListener('resize', requestPosition, { passive: true });
            window.addEventListener('scroll', requestPosition, { passive: true, capture: true });
            document.addEventListener('transitionend', onTransitionEnd, true);
            trackView('dropdown');
        }
        observeAnchor();
        positionDropdown();
        followAnchor(600);
    }

    function closeDropdown() {
        if (!dropdown.root || dropdown.root.hidden) {
            return;
        }
        dropdown.root.hidden = true;
        dropdown.frozen = false;
        window.removeEventListener('resize', requestPosition);
        window.removeEventListener('scroll', requestPosition, { capture: true });
        document.removeEventListener('transitionend', onTransitionEnd, true);
        cancelAnimationFrame(dropdown.follow);
        if (dropdown.observer) {
            dropdown.observer.disconnect();
        }
        if (state.activeInput) {
            state.activeInput.setAttribute('aria-expanded', 'false');
            state.activeInput.removeAttribute('aria-activedescendant');
        }
        if (state.surface === 'dropdown') {
            state.surface = null;
        }
    }

    /* ================================================================
       Mobiles Overlay
       ================================================================ */

    var overlay = { root: null, input: null, list: null, clear: null };

    var ICON_SEARCH = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M10.5 18a7.5 7.5 0 1 1 0-15 7.5 7.5 0 0 1 0 15Zm5.3-2.2L21 21"/></svg>';
    var ICON_CLEAR = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M6 6l12 12M18 6 6 18"/></svg>';

    function ensureOverlay() {
        if (overlay.root) {
            return;
        }
        var root = el('div', 'pjdcs-overlay');
        root.hidden = true;
        root.setAttribute('role', 'dialog');
        root.setAttribute('aria-modal', 'true');
        root.setAttribute('aria-label', T.mobileTitle || 'Suche');

        var head = el('div', 'pjdcs-ov-head');
        var form = el('form', 'pjdcs-ov-form');
        form.setAttribute('role', 'search');
        form.action = opts.searchUrl || '/search';
        form.method = 'get';

        var icon = el('span', 'pjdcs-ov-icon');
        icon.innerHTML = ICON_SEARCH;

        var input = el('input', 'pjdcs-ov-input');
        input.type = 'search';
        input.name = 'search';
        input.setAttribute('autocomplete', 'off');
        input.setAttribute('autocorrect', 'off');
        input.setAttribute('autocapitalize', 'off');
        input.setAttribute('spellcheck', 'false');
        input.setAttribute('enterkeyhint', 'search');
        input.setAttribute('role', 'combobox');
        input.setAttribute('aria-autocomplete', 'list');
        input.setAttribute('aria-expanded', 'true');
        input.setAttribute('aria-label', T.mobileTitle || 'Suche');

        var clear = el('button', 'pjdcs-ov-clear');
        clear.type = 'button';
        clear.hidden = true;
        clear.setAttribute('aria-label', T.clear || '');
        clear.innerHTML = ICON_CLEAR;

        form.appendChild(icon);
        form.appendChild(input);
        form.appendChild(clear);

        var close = el('button', 'pjdcs-ov-close', T.close);
        close.type = 'button';

        head.appendChild(form);
        head.appendChild(close);

        var body = el('div', 'pjdcs-ov-body');
        var list = el('div', 'pjdcs-results');
        list.id = 'pjdcs-overlay-list';
        list.setAttribute('role', 'listbox');
        input.setAttribute('aria-controls', list.id);
        body.appendChild(list);

        root.appendChild(head);
        root.appendChild(body);
        document.body.appendChild(root);

        input.addEventListener('input', function () {
            clear.hidden = !input.value;
            onQuery(input.value);
        });
        input.addEventListener('keydown', onKeydown);
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            submit(input.value);
        });
        clear.addEventListener('click', function () {
            input.value = '';
            clear.hidden = true;
            input.focus();
            onQuery('');
        });
        close.addEventListener('click', function () {
            closeOverlay(true);
        });
        // Beim Scrollen der Ergebnisse die Tastatur einklappen
        body.addEventListener('touchstart', function () {
            if (document.activeElement === input) {
                input.blur();
            }
        }, { passive: true });

        root.addEventListener('click', onResultClick);

        overlay.root = root;
        overlay.input = input;
        overlay.list = list;
        overlay.clear = clear;
    }

    function openOverlay(sourceInput) {
        ensureOverlay();
        closeDropdown();
        state.surface = 'overlay';
        state.activeInput = overlay.input;
        state.lastTrigger = document.activeElement;

        if (sourceInput && sourceInput.value && !overlay.input.value) {
            overlay.input.value = sourceInput.value;
        }
        if (T.placeholder || (sourceInput && sourceInput.placeholder)) {
            overlay.input.placeholder = T.placeholder || sourceInput.placeholder;
        }
        overlay.clear.hidden = !overlay.input.value;

        if (overlay.root.hidden) {
            overlay.root.hidden = false;
            document.documentElement.classList.add('pjdcs-locked');
            try {
                history.pushState({ pjdcs: true }, '');
                state.historyPushed = true;
            } catch (e) {
                state.historyPushed = false;
            }
            trackView('overlay');
        }

        // Fokus direkt im Klick setzen, sonst öffnet iOS die Tastatur nicht
        overlay.input.focus();
        onQuery(overlay.input.value);
    }

    function closeOverlay(fromUser) {
        if (!overlay.root || overlay.root.hidden) {
            return;
        }
        overlay.root.hidden = true;
        document.documentElement.classList.remove('pjdcs-locked');
        if (state.surface === 'overlay') {
            state.surface = null;
        }
        if (state.historyPushed) {
            state.historyPushed = false;
            if (fromUser && history.state && history.state.pjdcs) {
                history.back();
            }
        }
        if (fromUser && state.lastTrigger && state.lastTrigger.focus) {
            try {
                state.lastTrigger.focus({ preventScroll: true });
            } catch (e) { /* egal */ }
        }
    }

    function closeAll(fromUser) {
        closeDropdown();
        closeOverlay(fromUser);
    }

    /* ================================================================
       Suche
       ================================================================ */

    function currentList() {
        return state.surface === 'overlay' ? overlay.list : (dropdown.list || null);
    }

    function onQuery(value) {
        state.query = value;
        clearTimeout(state.debounceTimer);
        var query = value.trim();
        var key = cacheKey(query);
        var minChars = opts.minChars || 2;
        var effective = query.length >= minChars ? key : '';

        // Treffer aus dem Zwischenspeicher sofort zeigen
        if (cache.has(effective)) {
            show(effective, cache.get(effective));
            return;
        }

        var run = function () {
            var seq = ++state.seq;
            setLoading(true);
            fetchResults(effective).then(function (data) {
                if (seq !== state.seq) {
                    return;
                }
                setLoading(false);
                show(effective, data);
            }, function () {
                if (seq === state.seq) {
                    setLoading(false);
                }
            });
        };

        if (effective === '') {
            run();
        } else {
            state.debounceTimer = setTimeout(run, DEBOUNCE_MS);
        }
    }

    function show(query, data) {
        var list = currentList();
        if (!list || state.broken) {
            return;
        }
        state.response = data;
        render(list, data, query);
        if (state.surface === 'dropdown') {
            // Leeres Dropdown nicht anzeigen
            var hasContent = list.childNodes.length > 0;
            dropdown.root.classList.toggle('is-empty', !hasContent);
            positionDropdown();
        }
        if (query) {
            scheduleNoResults(query, data);
        }
    }

    function submit(value) {
        var query = value.trim();
        if (!query) {
            return;
        }
        var term = cleanTerm(query);
        var done = false;

        var go = function (url, target) {
            if (done) {
                return;
            }
            done = true;
            track('submit', target, term);
            window.location.href = url;
        };

        var timer = setTimeout(function () {
            go(searchPageUrl(query), 'ergebnisseite');
        }, SUBMIT_TIMEOUT_MS);

        fetchResults(query.length >= (opts.minChars || 2) ? query : '').then(function (data) {
            clearTimeout(timer);
            if (data.redirect) {
                go(data.redirect, data.redirectType || 'direktlink');
                return;
            }
            var single = singleResult(data);
            if (single) {
                go(single, 'treffer');
                return;
            }
            go(searchPageUrl(query), 'ergebnisseite');
        }, function () {
            clearTimeout(timer);
            go(searchPageUrl(query), 'ergebnisseite');
        });
    }

    function singleResult(data) {
        if (!data || data.total !== 1) {
            return null;
        }
        if (data.highlights && data.highlights.length === 1) {
            return data.highlights[0].url;
        }
        for (var i = 0; i < (data.groups || []).length; i++) {
            if (data.groups[i].items && data.groups[i].items.length === 1) {
                return data.groups[i].items[0].url;
            }
        }
        return null;
    }

    /* ================================================================
       Tastatur
       ================================================================ */

    function options() {
        var list = currentList();
        return list ? Array.prototype.slice.call(list.querySelectorAll('[role="option"]')) : [];
    }

    function setActive(index) {
        var items = options();
        if (!items.length) {
            return;
        }
        if (index < 0) {
            index = items.length - 1;
        }
        if (index >= items.length) {
            index = 0;
        }
        items.forEach(function (item, i) {
            item.setAttribute('aria-selected', i === index ? 'true' : 'false');
            item.classList.toggle('is-active', i === index);
        });
        state.activeIndex = index;
        if (state.activeInput) {
            state.activeInput.setAttribute('aria-activedescendant', items[index].id);
        }
        items[index].scrollIntoView({ block: 'nearest' });
    }

    function onKeydown(e) {
        if (state.broken || !state.surface) {
            return false;
        }
        switch (e.key) {
            case 'ArrowDown':
                e.preventDefault();
                setActive(state.activeIndex + 1);
                return true;
            case 'ArrowUp':
                e.preventDefault();
                setActive(state.activeIndex - 1);
                return true;
            case 'Enter':
                if (state.activeIndex >= 0) {
                    var item = options()[state.activeIndex];
                    if (item) {
                        e.preventDefault();
                        item.click();
                        return true;
                    }
                }
                return false;
            case 'Escape':
                e.preventDefault();
                if (state.surface === 'overlay') {
                    closeOverlay(true);
                } else {
                    closeDropdown();
                }
                return true;
            case 'Tab':
                if (state.surface === 'dropdown') {
                    closeDropdown();
                }
                return false;
            default:
                return false;
        }
    }

    /* ================================================================
       Klicks auf Treffer (Tracking)
       ================================================================ */

    function onResultClick(e) {
        var link = e.target.closest('[data-pjdcs-target]');
        if (!link) {
            return;
        }
        var term = cleanTerm(state.query);
        var title = link.getAttribute('data-pjdcs-title') || '';
        var target = link.getAttribute('data-pjdcs-target');
        var label = target === 'ergebnisseite' ? term : (term ? term + ' > ' + title : title);
        track('select', target, label, link.getAttribute('data-pjdcs-bm'), link.getAttribute('data-pjdcs-bv'));
    }

    /* ================================================================
       Einbindung ins Theme-Suchfeld
       Alle Listener laufen in der Capture-Phase auf document, damit die
       Shopware-Suchvorschläge gar nicht erst ausgelöst werden.
       ================================================================ */

    function onFocusIn(e) {
        var input = e.target;
        if (state.broken || !matchesInput(input)) {
            return;
        }
        state.sourceInput = input;
        if (isMobile()) {
            input.blur();
            openOverlay(input);
            return;
        }
        openDropdown(input);
        onQuery(input.value);
    }

    function onInput(e) {
        var input = e.target;
        if (state.broken || !matchesInput(input)) {
            return;
        }
        e.stopImmediatePropagation();
        if (isMobile()) {
            openOverlay(input);
            return;
        }
        if (state.surface !== 'dropdown' || state.activeInput !== input) {
            openDropdown(input);
        }
        onQuery(input.value);
    }

    function onDocumentKeydown(e) {
        if (state.broken || !matchesInput(e.target) || state.surface !== 'dropdown') {
            return;
        }
        if (onKeydown(e)) {
            e.stopImmediatePropagation();
        }
    }

    function onSubmit(e) {
        var form = e.target;
        if (state.broken || !form || form.classList.contains('pjdcs-ov-form')) {
            return;
        }
        var input = null;
        try {
            input = form.querySelector(opts.inputSelector);
        } catch (err) {
            input = null;
        }
        if (!input) {
            return;
        }
        e.preventDefault();
        e.stopImmediatePropagation();
        submit(input.value);
    }

    function onTriggerClick(e) {
        if (state.broken || !opts.mobileTriggerSelector || !isMobile()) {
            return;
        }
        var trigger;
        try {
            trigger = e.target.closest(opts.mobileTriggerSelector);
        } catch (err) {
            return;
        }
        if (!trigger) {
            return;
        }
        e.preventDefault();
        e.stopImmediatePropagation();
        openOverlay(state.sourceInput || document.querySelector(opts.inputSelector));
    }

    function onPointerDownOutside(e) {
        if (state.surface !== 'dropdown' || !dropdown.root) {
            return;
        }
        if (dropdown.root.contains(e.target) || matchesInput(e.target)) {
            return;
        }
        var form = state.activeInput && state.activeInput.closest('form');
        if (form && form.contains(e.target)) {
            return;
        }
        closeDropdown();
    }

    function warmUp() {
        // Schnelllinks vorladen, sobald das Suchfeld in Reichweite ist
        if (!cache.has('')) {
            fetchResults('').catch(function () { /* fallback läuft über disable() */ });
        }
    }

    function loadCss() {
        var href = configEl.getAttribute('data-css');
        if (!href || document.querySelector('link[data-pjdcs]')) {
            return;
        }
        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = href;
        link.setAttribute('data-pjdcs', '');
        document.head.appendChild(link);
    }

    /**
     * Keine-Treffer-Bereich auf der Shopware-Ergebnisseite (vom Server gerendert)
     */
    function initNoResultsPage() {
        var section = document.querySelector('[data-pjdcs-noresults]');
        if (!section) {
            return;
        }
        var term = cleanTerm(section.getAttribute('data-pjdcs-term'));
        track('view', 'no_results_page', term);
        section.addEventListener('click', function (e) {
            var link = e.target.closest('[data-pjdcs-target]');
            if (!link) {
                return;
            }
            var title = link.getAttribute('data-pjdcs-title') || '';
            track('select', link.getAttribute('data-pjdcs-target'), term ? term + ' > ' + title : title,
                link.getAttribute('data-pjdcs-bm'), link.getAttribute('data-pjdcs-bv'));
        });
    }

    function init() {
        loadCss();
        document.documentElement.classList.add('pjdcs-enabled');

        var inputs = [];
        try {
            inputs = Array.prototype.slice.call(document.querySelectorAll(opts.inputSelector));
        } catch (e) {
            log('Ungültiger Selektor', opts.inputSelector);
            return;
        }
        if (!inputs.length) {
            log('Kein Suchfeld gefunden für', opts.inputSelector);
        }
        inputs.forEach(function (input) {
            input.setAttribute('role', 'combobox');
            input.setAttribute('aria-autocomplete', 'list');
            input.setAttribute('aria-expanded', 'false');
            input.setAttribute('autocomplete', 'off');
            if (T.placeholder) {
                input.placeholder = T.placeholder;
            }
            input.addEventListener('pointerenter', warmUp, { once: true, passive: true });
            input.addEventListener('touchstart', warmUp, { once: true, passive: true });
        });

        document.addEventListener('focusin', onFocusIn, true);
        document.addEventListener('input', onInput, true);
        document.addEventListener('keydown', onDocumentKeydown, true);
        document.addEventListener('submit', onSubmit, true);
        document.addEventListener('click', onTriggerClick, true);
        document.addEventListener('mousedown', onPointerDownOutside, true);

        if (opts.mobileTriggerSelector) {
            try {
                Array.prototype.slice.call(document.querySelectorAll(opts.mobileTriggerSelector)).forEach(function (btn) {
                    btn.addEventListener('touchstart', warmUp, { once: true, passive: true });
                });
            } catch (e) { /* ungültiger Selektor: nur kein Vorladen */ }
        }

        // Zurück-Taste schließt das Overlay
        window.addEventListener('popstate', function () {
            if (overlay.root && !overlay.root.hidden) {
                state.historyPushed = false;
                closeOverlay(false);
            }
        });

        // Seite aus dem Browser-Verlauf (bfcache) wiederhergestellt
        window.addEventListener('pageshow', function (e) {
            if (e.persisted) {
                dropdown.frozen = false;
                closeAll(false);
            }
        });

        // Wechsel zwischen Handy- und Desktop-Ansicht (z. B. Drehen)
        var lastMobile = isMobile();
        window.addEventListener('resize', function () {
            var mobile = isMobile();
            if (mobile !== lastMobile) {
                lastMobile = mobile;
                closeAll(false);
            }
        }, { passive: true });

        initNoResultsPage();

        log('bereit, Version', opts.version, 'Suchfelder:', inputs.length);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
