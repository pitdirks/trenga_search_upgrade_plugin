/*!
 * pjdcustom_suche – Admin-Modul "Marketing > Suche"
 * Entwickelt von Pit Dirks.
 *
 * Fertige Datei ohne Build-Schritt: nutzt nur das globale Shopware-Objekt.
 * Pflege von Direktlinks, Synonymen und eigenen Einträgen sowie Index-Status.
 */
(function () {
    'use strict';

    if (!window.Shopware) {
        return;
    }

    var Shopware = window.Shopware;
    var Criteria = Shopware.Data.Criteria;

    /* ------------------------------------------------------------
       Konfiguration der drei Bereiche
       ------------------------------------------------------------ */

    var SECTIONS = {
        rules: {
            entity: 'pjdcustom_suche_rule',
            label: 'Direktlinks',
            singular: 'Direktlink',
            intro: 'Hervorgehobene Karte ganz oben in der Suche. Beispiel: Wer "Werkstatt", "Reparatur" oder "Inspektion" sucht, sieht sofort "Servicetermin buchen". Mit "Bei Enter direkt weiterleiten" führt Enter ohne Umweg zum Link.',
            sortBy: 'position',
            defaults: { active: true, redirectOnEnter: false, position: 0 },
            columns: [
                { key: 'title', label: 'Titel' },
                { key: 'keywords', label: 'Suchbegriffe', truncate: true },
                { key: 'url', label: 'Link', truncate: true },
                { key: 'redirectOnEnter', label: 'Enter leitet weiter', type: 'bool' },
                { key: 'active', label: 'Aktiv', type: 'bool' }
            ],
            fields: [
                { key: 'active', label: 'Aktiv', type: 'switch' },
                { key: 'title', label: 'Titel', type: 'text', required: true, help: 'Überschrift der Karte, z. B. "Servicetermin buchen".' },
                { key: 'description', label: 'Kurztext', type: 'textarea', help: 'Optional, eine Zeile unter dem Titel.' },
                { key: 'keywords', label: 'Suchbegriffe', type: 'textarea', required: true, help: 'Kommagetrennt. Groß-/Kleinschreibung, Umlaute, Plural und kleine Tippfehler werden automatisch erkannt. Beispiel: werkstatt, service, reparatur, inspektion, wartung' },
                { key: 'url', label: 'Link', type: 'text', required: true, url: true, help: 'Vollständige Adresse (https://...) oder Pfad im Shop (/service/termin).' },
                { key: 'buttonLabel', label: 'Button-Text', type: 'text', help: 'Leer = Standard-Text aus den Plugin-Einstellungen.' },
                { key: 'redirectOnEnter', label: 'Bei Enter direkt weiterleiten', type: 'switch', help: 'Drückt jemand nach einem passenden Begriff Enter, geht es direkt zum Link.' },
                { key: 'mediaId', label: 'Bild (optional)', type: 'media' },
                { key: 'position', label: 'Reihenfolge', type: 'number', help: 'Kleinere Zahl = weiter oben, wenn mehrere Direktlinks passen.' }
            ]
        },
        synonyms: {
            entity: 'pjdcustom_suche_synonym',
            label: 'Synonyme',
            singular: 'Synonym-Gruppe',
            intro: 'Alle Begriffe einer Gruppe werden gleich behandelt. Beispiel: "E-Bike, Pedelec, Elektrofahrrad" findet überall dieselben Treffer. Auch Begriffe aus mehreren Wörtern sind möglich ("tiefer Einstieg").',
            sortBy: 'createdAt',
            defaults: { active: true },
            columns: [
                { key: 'terms', label: 'Begriffe', truncate: true },
                { key: 'note', label: 'Notiz', truncate: true },
                { key: 'active', label: 'Aktiv', type: 'bool' }
            ],
            fields: [
                { key: 'active', label: 'Aktiv', type: 'switch' },
                { key: 'terms', label: 'Begriffe', type: 'textarea', required: true, help: 'Mindestens zwei, kommagetrennt. Beispiel: mtb, mountainbike, mountain bike' },
                { key: 'note', label: 'Notiz (nur intern)', type: 'text' }
            ]
        },
        entries: {
            entity: 'pjdcustom_suche_entry',
            label: 'Eigene Einträge',
            singular: 'Eintrag',
            intro: 'Seiten, die keine Kategorie oder kein Produkt sind: Standorte, Probefahrt, Kontakt, Jobs. Erscheinen in der Gruppe "Standorte & Service". Mit "Als Schnelllink zeigen" erscheinen sie zusätzlich bei leerem Suchfeld und wenn nichts gefunden wurde.',
            sortBy: 'position',
            defaults: { active: true, type: 'service', quickLink: false, position: 0 },
            columns: [
                { key: 'title', label: 'Titel' },
                { key: 'type', label: 'Art', type: 'type' },
                { key: 'url', label: 'Link', truncate: true },
                { key: 'quickLink', label: 'Schnelllink', type: 'bool' },
                { key: 'active', label: 'Aktiv', type: 'bool' }
            ],
            fields: [
                { key: 'active', label: 'Aktiv', type: 'switch' },
                { key: 'type', label: 'Art', type: 'select', options: [
                    { value: 'standort', label: 'Standort' },
                    { value: 'service', label: 'Service' },
                    { value: 'eintrag', label: 'Sonstiges' }
                ], help: 'Steuert das Symbol und das Tracking-Ziel (target).' },
                { key: 'title', label: 'Titel', type: 'text', required: true },
                { key: 'description', label: 'Kurztext', type: 'textarea', help: 'Erscheint unter dem Titel, z. B. Adresse oder Öffnungszeiten.' },
                { key: 'keywords', label: 'Suchbegriffe', type: 'textarea', help: 'Kommagetrennt, z. B. harburg, hamburg, laden, filiale, öffnungszeiten' },
                { key: 'url', label: 'Link', type: 'text', required: true, url: true, help: 'Vollständige Adresse (https://...) oder Pfad im Shop (/standorte/harburg).' },
                { key: 'quickLink', label: 'Als Schnelllink zeigen', type: 'switch' },
                { key: 'mediaId', label: 'Bild (optional)', type: 'media' },
                { key: 'position', label: 'Reihenfolge', type: 'number' }
            ]
        }
    };

    var TYPE_LABELS = { standort: 'Standort', service: 'Service', eintrag: 'Sonstiges' };

    /* ------------------------------------------------------------
       Styles des Moduls
       ------------------------------------------------------------ */

    var STYLE = [
        '.pjdcs-admin-intro{margin:0 0 20px;color:#52667a;line-height:1.5;max-width:860px}',
        '.pjdcs-admin-toolbar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:16px}',
        '.pjdcs-admin-table{width:100%;border-collapse:collapse;font-size:14px}',
        '.pjdcs-admin-table th{text-align:left;font-weight:600;color:#52667a;font-size:12px;padding:10px 12px;border-bottom:1px solid #d1d9e0}',
        '.pjdcs-admin-table td{padding:12px;border-bottom:1px solid #eef1f4;vertical-align:middle}',
        '.pjdcs-admin-table tr:hover td{background:#f9fafb}',
        '.pjdcs-admin-table .is-truncate{max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
        '.pjdcs-admin-table .is-actions{text-align:right;white-space:nowrap}',
        '.pjdcs-admin-table .is-actions button + button{margin-left:8px}',
        '.pjdcs-admin-dot{display:inline-block;width:10px;height:10px;border-radius:50%;background:#d1d9e0}',
        '.pjdcs-admin-dot.is-on{background:#37d046}',
        '.pjdcs-admin-empty{padding:32px;text-align:center;color:#52667a}',
        '.pjdcs-admin-search{max-width:320px;margin:0}',
        '.pjdcs-admin-status td:first-child{font-weight:600}',
        '.pjdcs-admin-hint{margin-top:20px;padding:14px 16px;background:#f4f7fa;border-radius:6px;color:#3d4a57;line-height:1.5}',
        '.pjdcs-admin-hint code{background:#fff;padding:1px 6px;border-radius:4px}'
    ].join('');

    function ensureStyle() {
        if (document.getElementById('pjdcs-admin-style')) {
            return;
        }
        var style = document.createElement('style');
        style.id = 'pjdcs-admin-style';
        style.textContent = STYLE;
        document.head.appendChild(style);
    }

    function isSafeUrl(url) {
        return /^(https?:\/\/|\/(?!\/))/i.test(String(url || '').trim());
    }

    function http() {
        return Shopware.Application.getContainer('init').httpClient;
    }

    function authHeaders() {
        return { Authorization: 'Bearer ' + Shopware.Service('loginService').getToken() };
    }

    /* ------------------------------------------------------------
       Liste + Bearbeiten (für alle drei Bereiche)
       ------------------------------------------------------------ */

    Shopware.Component.register('pjdcustom-suche-list', {
        template: [
            '<div>',
            '  <p class="pjdcs-admin-intro">{{ section.intro }}</p>',
            '  <div class="pjdcs-admin-toolbar">',
            '    <sw-text-field class="pjdcs-admin-search" v-model:value="term" placeholder="Durchsuchen ..." size="small"></sw-text-field>',
            '    <sw-button variant="primary" size="small" @click="openCreate">{{ section.singular }} anlegen</sw-button>',
            '  </div>',
            '  <sw-loader v-if="loading"></sw-loader>',
            '  <div v-else-if="!filteredItems.length" class="pjdcs-admin-empty">Noch keine Einträge vorhanden.</div>',
            '  <table v-else class="pjdcs-admin-table">',
            '    <thead><tr>',
            '      <th v-for="column in section.columns" :key="column.key">{{ column.label }}</th>',
            '      <th></th>',
            '    </tr></thead>',
            '    <tbody>',
            '      <tr v-for="item in filteredItems" :key="item.id">',
            '        <td v-for="column in section.columns" :key="column.key" :class="{ \'is-truncate\': column.truncate }" :title="column.truncate ? item[column.key] : null">',
            '          <span v-if="column.type === \'bool\'" class="pjdcs-admin-dot" :class="{ \'is-on\': item[column.key] }"></span>',
            '          <span v-else-if="column.type === \'type\'">{{ typeLabel(item[column.key]) }}</span>',
            '          <a v-else-if="column.key === \'title\'" href="#" @click.prevent="openEdit(item)">{{ item[column.key] }}</a>',
            '          <span v-else>{{ item[column.key] }}</span>',
            '        </td>',
            '        <td class="is-actions">',
            '          <sw-button size="x-small" @click="openEdit(item)">Bearbeiten</sw-button>',
            '          <sw-button size="x-small" variant="danger" @click="deleteCandidate = item">Löschen</sw-button>',
            '        </td>',
            '      </tr>',
            '    </tbody>',
            '  </table>',

            '  <sw-modal v-if="current" :title="(current._isNew ? \'Neu: \' : \'Bearbeiten: \') + section.singular" variant="large" @modal-close="closeModal">',
            '    <template v-for="field in section.fields" :key="field.key">',
            '      <sw-switch-field v-if="field.type === \'switch\'" v-model:value="current[field.key]" :label="field.label" :help-text="field.help" bordered></sw-switch-field>',
            '      <sw-text-field v-else-if="field.type === \'text\'" v-model:value="current[field.key]" :label="field.label" :help-text="field.help" :required="field.required" :error="errors[field.key]"></sw-text-field>',
            '      <sw-textarea-field v-else-if="field.type === \'textarea\'" v-model:value="current[field.key]" :label="field.label" :help-text="field.help" :required="field.required" :error="errors[field.key]"></sw-textarea-field>',
            '      <sw-number-field v-else-if="field.type === \'number\'" v-model:value="current[field.key]" number-type="int" :label="field.label" :help-text="field.help"></sw-number-field>',
            '      <sw-select-field v-else-if="field.type === \'select\'" v-model:value="current[field.key]" :label="field.label" :help-text="field.help">',
            '        <option v-for="option in field.options" :key="option.value" :value="option.value">{{ option.label }}</option>',
            '      </sw-select-field>',
            '      <sw-media-field v-else-if="field.type === \'media\'" v-model:value="current[field.key]" :label="field.label"></sw-media-field>',
            '    </template>',
            '    <template #modal-footer>',
            '      <sw-button size="small" @click="closeModal">Abbrechen</sw-button>',
            '      <sw-button variant="primary" size="small" :is-loading="saving" @click="save">Speichern</sw-button>',
            '    </template>',
            '  </sw-modal>',

            '  <sw-modal v-if="deleteCandidate" title="Wirklich löschen?" variant="small" @modal-close="deleteCandidate = null">',
            '    <p>"{{ deleteCandidate.title || deleteCandidate.terms }}" wird gelöscht. Das lässt sich nicht rückgängig machen.</p>',
            '    <template #modal-footer>',
            '      <sw-button size="small" @click="deleteCandidate = null">Abbrechen</sw-button>',
            '      <sw-button variant="danger" size="small" @click="remove">Löschen</sw-button>',
            '    </template>',
            '  </sw-modal>',
            '</div>'
        ].join(''),

        inject: ['repositoryFactory'],

        mixins: [Shopware.Mixin.getByName('notification')],

        props: {
            sectionKey: { type: String, required: true }
        },

        data: function () {
            return {
                items: [],
                loading: false,
                saving: false,
                current: null,
                errors: {},
                term: '',
                deleteCandidate: null
            };
        },

        computed: {
            section: function () {
                return SECTIONS[this.sectionKey];
            },
            repository: function () {
                return this.repositoryFactory.create(this.section.entity);
            },
            filteredItems: function () {
                var term = (this.term || '').trim().toLowerCase();
                if (!term) {
                    return this.items;
                }
                return this.items.filter(function (item) {
                    return ['title', 'keywords', 'terms', 'note', 'url', 'description'].some(function (key) {
                        return String(item[key] || '').toLowerCase().indexOf(term) !== -1;
                    });
                });
            }
        },

        created: function () {
            ensureStyle();
            this.load();
        },

        methods: {
            load: function () {
                var self = this;
                var criteria = new Criteria(1, 500);
                criteria.addSorting(Criteria.sort(this.section.sortBy, 'ASC'));
                if (this.section.sortBy !== 'createdAt') {
                    criteria.addSorting(Criteria.sort('createdAt', 'ASC'));
                }
                this.loading = true;
                return this.repository.search(criteria, Shopware.Context.api).then(function (result) {
                    self.items = Array.from(result);
                }).catch(function () {
                    self.createNotificationError({ message: 'Die Einträge konnten nicht geladen werden.' });
                }).finally(function () {
                    self.loading = false;
                });
            },

            typeLabel: function (value) {
                return TYPE_LABELS[value] || value;
            },

            openCreate: function () {
                var entity = this.repository.create(Shopware.Context.api);
                var defaults = this.section.defaults;
                Object.keys(defaults).forEach(function (key) {
                    entity[key] = defaults[key];
                });
                entity._isNew = true;
                this.errors = {};
                this.current = entity;
            },

            openEdit: function (item) {
                var self = this;
                this.errors = {};
                this.repository.get(item.id, Shopware.Context.api).then(function (entity) {
                    self.current = entity;
                });
            },

            closeModal: function () {
                this.current = null;
                this.errors = {};
            },

            validate: function () {
                var self = this;
                var errors = {};
                this.section.fields.forEach(function (field) {
                    var value = self.current[field.key];
                    if (field.required && (value === null || value === undefined || String(value).trim() === '')) {
                        errors[field.key] = { detail: 'Bitte ausfüllen.' };
                    } else if (field.url && value && !isSafeUrl(value)) {
                        errors[field.key] = { detail: 'Bitte mit https:// oder / beginnen.' };
                    }
                });
                if (this.sectionKey === 'synonyms' && !errors.terms) {
                    var count = String(this.current.terms || '').split(/[,;\n]+/).filter(function (t) { return t.trim(); }).length;
                    if (count < 2) {
                        errors.terms = { detail: 'Mindestens zwei Begriffe, kommagetrennt.' };
                    }
                }
                this.errors = errors;
                return Object.keys(errors).length === 0;
            },

            save: function () {
                var self = this;
                if (!this.validate()) {
                    this.createNotificationError({ message: 'Bitte die markierten Felder prüfen.' });
                    return;
                }
                this.saving = true;
                return this.repository.save(this.current, Shopware.Context.api).then(function () {
                    self.createNotificationSuccess({ message: self.section.singular + ' gespeichert. Die Suche nutzt die Änderung sofort.' });
                    self.closeModal();
                    return self.load();
                }).catch(function () {
                    self.createNotificationError({ message: 'Speichern fehlgeschlagen. Bitte Eingaben prüfen.' });
                }).finally(function () {
                    self.saving = false;
                });
            },

            remove: function () {
                var self = this;
                var item = this.deleteCandidate;
                this.deleteCandidate = null;
                return this.repository.delete(item.id, Shopware.Context.api).then(function () {
                    self.createNotificationSuccess({ message: 'Gelöscht.' });
                    return self.load();
                }).catch(function () {
                    self.createNotificationError({ message: 'Löschen fehlgeschlagen.' });
                });
            }
        }
    });

    /* ------------------------------------------------------------
       Index-Status
       ------------------------------------------------------------ */

    Shopware.Component.register('pjdcustom-suche-status', {
        template: [
            '<div>',
            '  <p class="pjdcs-admin-intro">Der Suchindex enthält alle Kategorien, Bikes und Zubehör-Artikel mit Bild und ab-Preis. Er aktualisiert sich automatisch etwa eine Minute nach dem Speichern von Produkten oder Kategorien und zusätzlich jede Nacht. Mit dem Button baust Du ihn sofort neu auf, z. B. nach dem ersten Aktivieren.</p>',
            '  <div class="pjdcs-admin-toolbar">',
            '    <span>Plugin-Version: <strong>{{ status ? status.pluginVersion : "–" }}</strong></span>',
            '    <sw-button variant="primary" size="small" :is-loading="indexing" @click="reindex">Index jetzt neu aufbauen</sw-button>',
            '  </div>',
            '  <sw-loader v-if="loading"></sw-loader>',
            '  <table v-else-if="status" class="pjdcs-admin-table pjdcs-admin-status">',
            '    <thead><tr><th>Verkaufskanal</th><th>Suche aktiv</th><th>Kategorien</th><th>Bikes</th><th>Zubehör</th><th>Stand</th><th>Dauer</th></tr></thead>',
            '    <tbody>',
            '      <tr v-for="channel in status.channels" :key="channel.salesChannelId">',
            '        <td>{{ channelName(channel) }}</td>',
            '        <td><span class="pjdcs-admin-dot" :class="{ \'is-on\': channel.active }"></span></td>',
            '        <td>{{ count(channel, "category") }}</td>',
            '        <td>{{ count(channel, "bike") }}</td>',
            '        <td>{{ count(channel, "accessory") }}</td>',
            '        <td>{{ channel.state && channel.state.indexedAt ? formatDate(channel.state.indexedAt) : (channel.active ? "noch nicht indexiert" : "–") }}</td>',
            '        <td>{{ channel.state && channel.state.durationMs !== undefined ? channel.state.durationMs + " ms" : "–" }}</td>',
            '      </tr>',
            '    </tbody>',
            '  </table>',
            '  <div class="pjdcs-admin-hint">',
            '    <strong>Tipps</strong><br>',
            '    Zusätzliche Suchbegriffe, einen eigenen Kurztext oder "Nicht in der Suche anzeigen" gibt es an jeder Kategorie und jedem Produkt im Tab "Zusatzfelder" unter "Suche (pjdcustom)".<br>',
            '    Einstellungen, Texte und Zubehör-Kategorien: Erweiterungen &gt; Meine Erweiterungen &gt; pjdcustom_suche &gt; Konfigurieren.<br>',
            '    Konsole: <code>php bin/console pjdcustom:suche:index</code>',
            '  </div>',
            '</div>'
        ].join(''),

        inject: ['repositoryFactory'],

        mixins: [Shopware.Mixin.getByName('notification')],

        data: function () {
            return { status: null, loading: false, indexing: false, names: {} };
        },

        created: function () {
            ensureStyle();
            this.loadNames();
            this.load();
        },

        methods: {
            load: function () {
                var self = this;
                this.loading = true;
                return http().get('/_action/pjdcustom-suche/status', { headers: authHeaders() }).then(function (response) {
                    self.status = response.data;
                }).catch(function () {
                    self.createNotificationError({ message: 'Status konnte nicht geladen werden.' });
                }).finally(function () {
                    self.loading = false;
                });
            },

            loadNames: function () {
                var self = this;
                var repository = this.repositoryFactory.create('sales_channel');
                return repository.search(new Criteria(1, 50), Shopware.Context.api).then(function (result) {
                    var names = {};
                    Array.from(result).forEach(function (channel) {
                        names[channel.id] = channel.translated && channel.translated.name ? channel.translated.name : channel.name;
                    });
                    self.names = names;
                }).catch(function () { /* Namen sind optional */ });
            },

            reindex: function () {
                var self = this;
                this.indexing = true;
                return http().post('/_action/pjdcustom-suche/reindex', {}, { headers: authHeaders() }).then(function (response) {
                    var results = (response.data && response.data.results) || {};
                    var ids = Object.keys(results);
                    var failed = ids.filter(function (id) { return results[id].error; });
                    var active = ids.filter(function (id) { return results[id].active && !results[id].error; });
                    if (failed.length) {
                        self.createNotificationError({ message: 'Fehler beim Indexieren: ' + results[failed[0]].error });
                    } else if (!active.length) {
                        self.createNotificationWarning({ message: 'Kein Verkaufskanal hat die Suche aktiviert. Bitte in der Plugin-Konfiguration für den gewünschten Verkaufskanal einschalten und speichern.' });
                    } else {
                        var summary = active.map(function (id) {
                            var c = results[id].counts || {};
                            return (self.names[id] || results[id].salesChannelName || id) + ': ' + (c.category || 0) + ' Kategorien, ' + (c.bike || 0) + ' Bikes, ' + (c.accessory || 0) + ' Zubehör';
                        }).join(' | ');
                        self.createNotificationSuccess({ message: 'Suchindex neu aufgebaut. ' + summary });
                    }
                    return self.load();
                }).catch(function () {
                    self.createNotificationError({ message: 'Neuaufbau fehlgeschlagen. Details stehen im Shopware-Log.' });
                }).finally(function () {
                    self.indexing = false;
                });
            },

            channelName: function (channel) {
                return this.names[channel.salesChannelId] || (channel.state && channel.state.salesChannelName) || channel.salesChannelId;
            },

            count: function (channel, type) {
                return channel.state && channel.state.counts && channel.state.counts[type] !== undefined ? channel.state.counts[type] : '–';
            },

            formatDate: function (value) {
                try {
                    return new Date(value).toLocaleString('de-DE', { dateStyle: 'medium', timeStyle: 'short' });
                } catch (e) {
                    return value;
                }
            }
        }
    });

    /* ------------------------------------------------------------
       Seite mit Tabs
       ------------------------------------------------------------ */

    Shopware.Component.register('pjdcustom-suche-index', {
        template: [
            '<sw-page class="pjdcustom-suche-index">',
            '  <template #smart-bar-header><h2>Suche (pjdcustom)</h2></template>',
            '  <template #content>',
            '    <sw-card-view>',
            '      <sw-tabs position-identifier="pjdcustom-suche-tabs" default-item="rules">',
            '        <template #default>',
            '          <sw-tabs-item v-for="tab in tabs" :key="tab.name" :name="tab.name" :active-tab="activeTab" @click="activeTab = tab.name">{{ tab.label }}</sw-tabs-item>',
            '        </template>',
            '      </sw-tabs>',
            '      <sw-card :title="currentLabel" position-identifier="pjdcustom-suche-card">',
            '        <pjdcustom-suche-status v-if="activeTab === \'status\'"></pjdcustom-suche-status>',
            '        <pjdcustom-suche-list v-else :key="activeTab" :section-key="activeTab"></pjdcustom-suche-list>',
            '      </sw-card>',
            '    </sw-card-view>',
            '  </template>',
            '</sw-page>'
        ].join(''),

        data: function () {
            return {
                activeTab: 'rules',
                tabs: [
                    { name: 'rules', label: SECTIONS.rules.label },
                    { name: 'synonyms', label: SECTIONS.synonyms.label },
                    { name: 'entries', label: SECTIONS.entries.label },
                    { name: 'status', label: 'Index & Status' }
                ]
            };
        },

        computed: {
            currentLabel: function () {
                var tab = this.tabs.filter(function (t) { return t.name === this.activeTab; }, this)[0];
                return tab ? tab.label : '';
            }
        },

        metaInfo: function () {
            return { title: 'Suche (pjdcustom)' };
        }
    });

    /* ------------------------------------------------------------
       Modul und Menüpunkt Marketing > Suche
       ------------------------------------------------------------ */

    Shopware.Module.register('pjdcustom-suche', {
        type: 'plugin',
        name: 'pjdcustom-suche',
        title: 'Suche (pjdcustom)',
        description: 'Direktlinks, Synonyme und eigene Einträge der Shop-Suche',
        color: '#111111',
        icon: 'regular-search',
        routes: {
            index: {
                component: 'pjdcustom-suche-index',
                path: 'index'
            }
        },
        navigation: [{
            id: 'pjdcustom-suche',
            label: 'Suche',
            color: '#111111',
            path: 'pjdcustom.suche.index',
            icon: 'regular-search',
            parent: 'sw-marketing',
            position: 100
        }]
    });
})();
