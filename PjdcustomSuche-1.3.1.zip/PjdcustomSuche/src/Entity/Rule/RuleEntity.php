<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Entity\Rule;

use Shopware\Core\Content\Media\MediaEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityIdTrait;

class RuleEntity extends Entity
{
    use EntityIdTrait;

    protected bool $active = false;
    protected string $title;
    protected ?string $description = null;
    protected ?string $buttonLabel = null;
    protected string $url;
    protected string $keywords;
    protected bool $redirectOnEnter = false;
    protected ?int $position = null;
    protected ?string $mediaId = null;
    protected ?MediaEntity $media = null;

    public function getActive(): bool
    {
        return $this->active;
    }

    public function setActive(bool $active): void
    {
        $this->active = $active;
    }

    public function getTitle(): string
    {
        return $this->title;
    }

    public function setTitle(string $title): void
    {
        $this->title = $title;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): void
    {
        $this->description = $description;
    }

    public function getButtonLabel(): ?string
    {
        return $this->buttonLabel;
    }

    public function setButtonLabel(?string $buttonLabel): void
    {
        $this->buttonLabel = $buttonLabel;
    }

    public function getUrl(): string
    {
        return $this->url;
    }

    public function setUrl(string $url): void
    {
        $this->url = $url;
    }

    public function getKeywords(): string
    {
        return $this->keywords;
    }

    public function setKeywords(string $keywords): void
    {
        $this->keywords = $keywords;
    }

    public function getRedirectOnEnter(): bool
    {
        return $this->redirectOnEnter;
    }

    public function setRedirectOnEnter(bool $redirectOnEnter): void
    {
        $this->redirectOnEnter = $redirectOnEnter;
    }

    public function getPosition(): ?int
    {
        return $this->position;
    }

    public function setPosition(?int $position): void
    {
        $this->position = $position;
    }

    public function getMediaId(): ?string
    {
        return $this->mediaId;
    }

    public function getMedia(): ?MediaEntity
    {
        return $this->media;
    }
}
