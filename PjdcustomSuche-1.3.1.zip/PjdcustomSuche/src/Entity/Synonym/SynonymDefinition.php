<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Entity\Synonym;

use Shopware\Core\Framework\DataAbstractionLayer\Field\BoolField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\ApiAware;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\PrimaryKey;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\Required;
use Shopware\Core\Framework\DataAbstractionLayer\Field\IdField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\LongTextField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\StringField;
use Shopware\Core\Framework\DataAbstractionLayer\EntityDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;

/**
 * Synonym-Gruppe: alle Begriffe einer Zeile werden gleich behandelt.
 */
class SynonymDefinition extends EntityDefinition
{
    public const ENTITY_NAME = 'pjdcustom_suche_synonym';

    public function getEntityName(): string
    {
        return self::ENTITY_NAME;
    }

    public function getEntityClass(): string
    {
        return SynonymEntity::class;
    }

    public function getCollectionClass(): string
    {
        return SynonymCollection::class;
    }

    public function getDefaults(): array
    {
        return ['active' => true];
    }

    protected function defineFields(): FieldCollection
    {
        return new FieldCollection([
            (new IdField('id', 'id'))->addFlags(new ApiAware(), new PrimaryKey(), new Required()),
            (new BoolField('active', 'active'))->addFlags(new ApiAware()),
            (new LongTextField('terms', 'terms'))->addFlags(new ApiAware(), new Required()),
            (new StringField('note', 'note', 255))->addFlags(new ApiAware()),
        ]);
    }
}
