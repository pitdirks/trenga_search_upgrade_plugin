<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Entity\Synonym;

use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityIdTrait;

class SynonymEntity extends Entity
{
    use EntityIdTrait;

    protected bool $active = false;
    protected string $terms;
    protected ?string $note = null;

    public function getActive(): bool
    {
        return $this->active;
    }

    public function setActive(bool $active): void
    {
        $this->active = $active;
    }

    public function getTerms(): string
    {
        return $this->terms;
    }

    public function setTerms(string $terms): void
    {
        $this->terms = $terms;
    }

    public function getNote(): ?string
    {
        return $this->note;
    }

    public function setNote(?string $note): void
    {
        $this->note = $note;
    }
}
