<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Entity\Synonym;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

/**
 * @extends EntityCollection<SynonymEntity>
 */
class SynonymCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return SynonymEntity::class;
    }
}
