<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Entity\Entry;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

/**
 * @extends EntityCollection<EntryEntity>
 */
class EntryCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return EntryEntity::class;
    }
}
