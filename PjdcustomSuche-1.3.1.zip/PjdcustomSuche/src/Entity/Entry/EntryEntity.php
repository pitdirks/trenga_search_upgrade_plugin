<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Entity\Entry;

use Shopware\Core\Content\Media\MediaEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityIdTrait;

class EntryEntity extends Entity
{
    use EntityIdTrait;

    protected bool $active = false;
    protected string $type;
    protected string $title;
    protected ?string $description = null;
    protected string $url;
    protected ?string $keywords = null;
    protected bool $quickLink = false;
    protected ?int $position = null;
    protected ?string $mediaId = null;
    protected ?MediaEntity $media = null;

    public function getActive(): bool
    {
        return $this->active;
    }

    public function setActive(bool $active): void
    {
        $this->active = $active;
    }

    public function getType(): string
    {
        return $this->type;
    }

    public function setType(string $type): void
    {
        $this->type = $type;
    }

    public function getTitle(): string
    {
        return $this->title;
    }

    public function setTitle(string $title): void
    {
        $this->title = $title;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): void
    {
        $this->description = $description;
    }

    public function getUrl(): string
    {
        return $this->url;
    }

    public function setUrl(string $url): void
    {
        $this->url = $url;
    }

    public function getKeywords(): ?string
    {
        return $this->keywords;
    }

    public function setKeywords(?string $keywords): void
    {
        $this->keywords = $keywords;
    }

    public function getQuickLink(): bool
    {
        return $this->quickLink;
    }

    public function setQuickLink(bool $quickLink): void
    {
        $this->quickLink = $quickLink;
    }

    public function getPosition(): ?int
    {
        return $this->position;
    }

    public function setPosition(?int $position): void
    {
        $this->position = $position;
    }

    public function getMediaId(): ?string
    {
        return $this->mediaId;
    }

    public function getMedia(): ?MediaEntity
    {
        return $this->media;
    }
}
