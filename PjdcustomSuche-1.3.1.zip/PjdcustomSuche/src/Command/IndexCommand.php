<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Command;

use Pjdcustom\Suche\Service\SearchIndexer;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

/**
 * php bin/console pjdcustom:suche:index
 * Baut den Suchindex sofort für alle Verkaufskanäle neu auf.
 */
#[AsCommand(name: 'pjdcustom:suche:index', description: 'Baut den Suchindex von pjdcustom_suche neu auf')]
class IndexCommand extends Command
{
    public function __construct(private readonly SearchIndexer $indexer)
    {
        parent::__construct();
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $rows = [];
        $failed = false;

        foreach ($this->indexer->indexAll() as $salesChannelId => $result) {
            if (isset($result['error'])) {
                $failed = true;
            }
            $counts = $result['counts'] ?? [];
            $rows[] = [
                $result['salesChannelName'] ?? $salesChannelId,
                !empty($result['active']) ? 'ja' : 'nein',
                $counts['category'] ?? '-',
                $counts['bike'] ?? '-',
                $counts['accessory'] ?? '-',
                isset($result['durationMs']) ? $result['durationMs'] . ' ms' : '-',
                $result['error'] ?? '',
            ];
        }

        $io->table(['Verkaufskanal', 'Aktiv', 'Kategorien', 'Bikes', 'Zubehör', 'Dauer', 'Fehler'], $rows);

        return $failed ? Command::FAILURE : Command::SUCCESS;
    }
}
