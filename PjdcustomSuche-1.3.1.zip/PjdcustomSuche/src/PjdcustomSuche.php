<?php declare(strict_types=1);

namespace Pjdcustom\Suche;

use Doctrine\DBAL\Connection;
use Pjdcustom\Suche\Service\CustomFieldInstaller;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\Plugin;
use Shopware\Core\Framework\Plugin\Context\ActivateContext;
use Shopware\Core\Framework\Plugin\Context\InstallContext;
use Shopware\Core\Framework\Plugin\Context\UninstallContext;
use Shopware\Core\Framework\Plugin\Context\UpdateContext;

/**
 * pjdcustom_suche
 * Eigene, schnelle Shop-Suche für trenga.de. Entwickelt von Pit Dirks.
 *
 * Überblick:
 *   Einstellungen:    src/Resources/config/config.xml
 *   Pflege (Admin):   Marketing > Suche  (src/Resources/public/administration/js)
 *   Suchindex:        src/Service/SearchIndexer.php
 *   Suchlogik:        src/Service/SearchService.php
 *   Storefront:       src/Resources/public/storefront/  (eingebunden über base.html.twig)
 *
 * Sicherheit: Das Plugin ist nach der Installation pro Verkaufskanal AUS.
 * Erst wenn "Suche aktiv" gesetzt ist, greift es im Shop. Ist es aus oder
 * schlägt etwas fehl, läuft die normale Shopware-Suche unverändert weiter.
 */
class PjdcustomSuche extends Plugin
{
    public function install(InstallContext $installContext): void
    {
        parent::install($installContext);
        $this->customFieldInstaller()->install($installContext->getContext());
    }

    public function update(UpdateContext $updateContext): void
    {
        parent::update($updateContext);
        $this->customFieldInstaller()->install($updateContext->getContext());
    }

    public function activate(ActivateContext $activateContext): void
    {
        parent::activate($activateContext);
        $this->customFieldInstaller()->install($activateContext->getContext());
    }

    public function uninstall(UninstallContext $uninstallContext): void
    {
        parent::uninstall($uninstallContext);

        if ($uninstallContext->keepUserData()) {
            return;
        }

        /** @var Connection $connection */
        $connection = $this->container->get(Connection::class);
        foreach (['pjdcustom_suche_index', 'pjdcustom_suche_state', 'pjdcustom_suche_rule', 'pjdcustom_suche_synonym', 'pjdcustom_suche_entry'] as $table) {
            $connection->executeStatement('DROP TABLE IF EXISTS `' . $table . '`');
        }

        $this->customFieldInstaller()->uninstall($uninstallContext->getContext());
    }

    private function customFieldInstaller(): CustomFieldInstaller
    {
        /** @var EntityRepository $setRepository */
        $setRepository = $this->container->get('custom_field_set.repository');

        return new CustomFieldInstaller($setRepository);
    }
}
