<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Controller;

use Pjdcustom\Suche\Service\ConfigReader;
use Pjdcustom\Suche\Service\SearchIndexer;
use Shopware\Core\Framework\Context;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Attribute\Route;

/**
 * Admin-API für das Modul Marketing > Suche:
 *   GET  /api/_action/pjdcustom-suche/status   Stand des Index je Verkaufskanal
 *   POST /api/_action/pjdcustom-suche/reindex  Index sofort neu aufbauen
 */
#[Route(defaults: ['_routeScope' => ['api']])]
class AdminApiController
{
    public function __construct(
        private readonly SearchIndexer $indexer,
        private readonly ConfigReader $config
    ) {
    }

    #[Route(path: '/api/_action/pjdcustom-suche/status', name: 'api.action.pjdcustom.suche.status', methods: ['GET'])]
    public function status(Context $context): JsonResponse
    {
        $channels = [];
        foreach ($this->indexer->storefrontSalesChannelIds() as $salesChannelId) {
            $channels[] = [
                'salesChannelId' => $salesChannelId,
                'active' => $this->config->isActive($salesChannelId),
                'state' => $this->indexer->readState('index:' . $salesChannelId),
            ];
        }

        return new JsonResponse([
            'pluginVersion' => $this->config->pluginVersion(),
            'channels' => $channels,
        ]);
    }

    #[Route(path: '/api/_action/pjdcustom-suche/reindex', name: 'api.action.pjdcustom.suche.reindex', methods: ['POST'])]
    public function reindex(Context $context): JsonResponse
    {
        return new JsonResponse(['results' => $this->indexer->indexAll()]);
    }
}
