<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Controller;

use Pjdcustom\Suche\Service\ConfigReader;
use Pjdcustom\Suche\Service\SearchService;
use Psr\Log\LoggerInterface;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Storefront\Controller\StorefrontController;
use Shopware\Storefront\Framework\Routing\RequestTransformer;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;

/**
 * Liefert die Suchvorschläge als JSON an das Overlay.
 * GET /pjdcustom-suche/suggest?q=gravel
 *
 * Bei einem Fehler kommt eine leere Antwort mit "fallback": true zurück,
 * dann nutzt das Overlay die normale Shopware-Suche.
 */
#[Route(defaults: ['_routeScope' => ['storefront']])]
class SuggestController extends StorefrontController
{
    public function __construct(
        private readonly SearchService $searchService,
        private readonly ConfigReader $config,
        private readonly LoggerInterface $logger
    ) {
    }

    #[Route(
        path: '/pjdcustom-suche/suggest',
        name: 'frontend.pjdcustom.suche.suggest',
        defaults: ['XmlHttpRequest' => true],
        methods: ['GET']
    )]
    public function suggest(Request $request, SalesChannelContext $context): JsonResponse
    {
        $start = microtime(true);

        if (!$this->config->isActive($context->getSalesChannelId())) {
            return $this->respond(['fallback' => true], 404);
        }

        try {
            $baseUrl = (string) $request->attributes->get(RequestTransformer::STOREFRONT_URL, '');
            $payload = $this->searchService->suggest((string) $request->query->get('q', ''), $context, $baseUrl);
        } catch (\Throwable $e) {
            $this->logger->error('pjdcustom_suche: Suche fehlgeschlagen', ['error' => $e->getMessage()]);

            return $this->respond(['fallback' => true], 500);
        }

        $payload['ms'] = (int) round((microtime(true) - $start) * 1000);

        return $this->respond($payload);
    }

    /**
     * @param array<string, mixed> $data
     */
    private function respond(array $data, int $status = 200): JsonResponse
    {
        $response = new JsonResponse($data, $status);
        $response->setEncodingOptions(\JSON_UNESCAPED_UNICODE | \JSON_UNESCAPED_SLASHES | \JSON_HEX_TAG);
        $response->headers->set('X-Robots-Tag', 'noindex, nofollow');
        $response->headers->set('Cache-Control', 'no-store');

        return $response;
    }
}
