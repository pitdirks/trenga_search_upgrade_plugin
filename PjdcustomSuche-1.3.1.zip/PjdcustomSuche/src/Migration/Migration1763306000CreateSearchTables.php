<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

/**
 * Tabellen der Suche:
 *   pjdcustom_suche_index    Suchindex (Kategorien, Bikes, Zubehör) je Verkaufskanal und Sprache
 *   pjdcustom_suche_state    Status des Index (Zeitpunkt, Anzahl)
 *   pjdcustom_suche_rule     Direktlinks (z. B. Werkstatt -> Servicetermin)
 *   pjdcustom_suche_synonym  Synonym-Gruppen
 *   pjdcustom_suche_entry    Eigene Einträge (Standorte, Service, Schnelllinks)
 */
class Migration1763306000CreateSearchTables extends MigrationStep
{
    public function getCreationTimestamp(): int
    {
        return 1763306000;
    }

    public function update(Connection $connection): void
    {
        $connection->executeStatement('
            CREATE TABLE IF NOT EXISTS `pjdcustom_suche_index` (
                `id` BINARY(16) NOT NULL,
                `sales_channel_id` BINARY(16) NOT NULL,
                `language_id` BINARY(16) NOT NULL,
                `type` VARCHAR(20) NOT NULL,
                `entity_id` BINARY(16) NOT NULL,
                `title` VARCHAR(255) NOT NULL,
                `subtitle` VARCHAR(255) NULL,
                `url` VARCHAR(2048) NOT NULL,
                `image` VARCHAR(2048) NULL,
                `price` DOUBLE NULL,
                `price_formatted` VARCHAR(64) NULL,
                `is_sale` TINYINT(1) NOT NULL DEFAULT 0,
                `available` TINYINT(1) NOT NULL DEFAULT 1,
                `bike_model` VARCHAR(64) NULL,
                `bike_variant` VARCHAR(255) NULL,
                `keywords_text` TEXT NULL,
                `context_text` TEXT NULL,
                `position` INT NOT NULL DEFAULT 0,
                `created_at` DATETIME(3) NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx.pjdcustom_suche_index.channel` (`sales_channel_id`, `language_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ');

        $connection->executeStatement('
            CREATE TABLE IF NOT EXISTS `pjdcustom_suche_state` (
                `state_key` VARCHAR(120) NOT NULL,
                `value` LONGTEXT NULL,
                `updated_at` DATETIME(3) NOT NULL,
                PRIMARY KEY (`state_key`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ');

        $connection->executeStatement('
            CREATE TABLE IF NOT EXISTS `pjdcustom_suche_rule` (
                `id` BINARY(16) NOT NULL,
                `active` TINYINT(1) NOT NULL DEFAULT 1,
                `title` VARCHAR(255) NOT NULL,
                `description` TEXT NULL,
                `button_label` VARCHAR(255) NULL,
                `url` VARCHAR(2048) NOT NULL,
                `keywords` TEXT NOT NULL,
                `redirect_on_enter` TINYINT(1) NOT NULL DEFAULT 0,
                `media_id` BINARY(16) NULL,
                `position` INT NOT NULL DEFAULT 0,
                `created_at` DATETIME(3) NOT NULL,
                `updated_at` DATETIME(3) NULL,
                PRIMARY KEY (`id`),
                CONSTRAINT `fk.pjdcustom_suche_rule.media_id` FOREIGN KEY (`media_id`)
                    REFERENCES `media` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ');

        $connection->executeStatement('
            CREATE TABLE IF NOT EXISTS `pjdcustom_suche_synonym` (
                `id` BINARY(16) NOT NULL,
                `active` TINYINT(1) NOT NULL DEFAULT 1,
                `terms` TEXT NOT NULL,
                `note` VARCHAR(255) NULL,
                `created_at` DATETIME(3) NOT NULL,
                `updated_at` DATETIME(3) NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ');

        $connection->executeStatement('
            CREATE TABLE IF NOT EXISTS `pjdcustom_suche_entry` (
                `id` BINARY(16) NOT NULL,
                `active` TINYINT(1) NOT NULL DEFAULT 1,
                `type` VARCHAR(20) NOT NULL DEFAULT \'service\',
                `title` VARCHAR(255) NOT NULL,
                `description` TEXT NULL,
                `url` VARCHAR(2048) NOT NULL,
                `keywords` TEXT NULL,
                `quick_link` TINYINT(1) NOT NULL DEFAULT 0,
                `media_id` BINARY(16) NULL,
                `position` INT NOT NULL DEFAULT 0,
                `created_at` DATETIME(3) NOT NULL,
                `updated_at` DATETIME(3) NULL,
                PRIMARY KEY (`id`),
                CONSTRAINT `fk.pjdcustom_suche_entry.media_id` FOREIGN KEY (`media_id`)
                    REFERENCES `media` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ');
    }

    public function updateDestructive(Connection $connection): void
    {
    }
}
