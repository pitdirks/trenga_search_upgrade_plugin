<?php declare(strict_types=1);

namespace Pjdcustom\Suche\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

/**
 * 1.1.0: Verkaufszahlen im Suchindex (für "Bestseller" im Keine-Treffer-Bereich).
 */
class Migration1763380000AddSalesToIndex extends MigrationStep
{
    public function getCreationTimestamp(): int
    {
        return 1763380000;
    }

    public function update(Connection $connection): void
    {
        $columns = $connection->fetchFirstColumn(
            'SELECT COLUMN_NAME FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = \'pjdcustom_suche_index\''
        );

        if (!\in_array('sales', $columns, true)) {
            $connection->executeStatement(
                'ALTER TABLE `pjdcustom_suche_index` ADD COLUMN `sales` INT NOT NULL DEFAULT 0 AFTER `available`'
            );
        }
    }

    public function updateDestructive(Connection $connection): void
    {
    }
}
