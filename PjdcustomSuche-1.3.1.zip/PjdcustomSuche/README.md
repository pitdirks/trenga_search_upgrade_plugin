# pjdcustom_suche

Schnelle Shop-Suche für trenga.de. Entwickelt von Pit Dirks.

## Einrichten (zuerst auf dev)

1. ZIP unter Erweiterungen > Meine Erweiterungen hochladen, installieren, aktivieren.
2. Konfigurieren: oben den Verkaufskanal wählen, "Suche in diesem Verkaufskanal aktiv" einschalten.
   Optional Zubehör-Kategorien und ausgeschlossene Kategorien wählen. Speichern.
3. Marketing > Suche > Index & Status: "Index jetzt neu aufbauen".
4. Marketing > Suche: Direktlinks, Synonyme und eigene Einträge anlegen.
5. Cache leeren (Einstellungen > System > Caches & Indizes), Shop neu laden.

## Gut zu wissen

- Ausschalten: Schalter in der Konfiguration aus. Dann läuft sofort wieder die Shopware-Suche.
- Debug: In der Konfiguration "Debug-Modus" an, dann zeigt die Browser-Konsole (F12)
  Antwortzeiten und jedes Tracking-Event.
- Zusätzliche Suchbegriffe für eine Kategorie oder ein Produkt: Tab "Zusatzfelder",
  Bereich "Suche (pjdcustom)".
- Der Index aktualisiert sich über die Message Queue. Läuft auf dem Server kein Worker
  und ist der Admin-Worker aus, zusätzlich per Cronjob ausführen:
  `php bin/console pjdcustom:suche:index`

## Tracking (dataLayer)

Event `pjdcustom_interaction`, `element` = `suche`:

| action | target | label |
|---|---|---|
| view | dropdown / overlay | – (einmal pro Seitenaufruf) |
| view | no_results | Suchbegriff |
| view | no_results_page | Suchbegriff (Ergebnisseite mit Keine-Treffer-Bereich) |
| select | kategorie, bike, zubehoer, standort, service, eintrag, direktlink, schnelllink, empfehlung, ergebnisseite | "Suchbegriff > Treffer" |
| submit | direktlink, kategorie, treffer, ergebnisseite | Suchbegriff |

Bei Bikes zusätzlich `bike_model` und `bike_variant`. Suchbegriffe mit @ oder langen
Ziffernfolgen werden nicht übertragen.
